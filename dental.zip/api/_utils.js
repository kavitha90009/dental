// =============================================================================
// /api/_utils — shared helpers for the serverless functions
// =============================================================================
//
// Centralizes small utilities that were previously copy-pasted across several
// endpoints (auth header parsing, body parsing, JSON error responses, phone
// normalization, FCM data stringification). Underscore-prefixed so Vercel does
// NOT expose it as its own serverless function.
// =============================================================================

// Extract the token from an "Authorization: Bearer <token>" header.
function getBearerToken(header) {
    if (!header) return '';
    var parts = String(header).split(' ');
    return parts.length === 2 && /^Bearer$/i.test(parts[0]) ? parts[1] : '';
}

// Parse a request body that may arrive as an object or a JSON string.
function parseBody(body) {
    if (!body) return {};
    if (typeof body === 'object') return body;
    try {
        return JSON.parse(body);
    } catch (err) {
        return {};
    }
}

// Uniform JSON error response. `requiredPlan` is optional (used by the
// feature-gated endpoints to tell the client which plan is needed).
function jsonError(res, status, code, message, requiredPlan) {
    var payload = {
        success: false,
        ok: false,
        error: code,
        code: code,
        message: message,
    };
    if (requiredPlan) payload.requiredPlan = requiredPlan;
    return res.status(status).json(payload);
}

// Coerce all values of a data map to strings (FCM data payloads must be
// string→string), dropping null/undefined entries.
function stringData(data) {
    var out = {};
    Object.keys(data || {}).forEach(function(k) {
        if (data[k] !== undefined && data[k] !== null) out[k] = String(data[k]);
    });
    return out;
}

// Phone normalization — MUST mirror the dashboard/Flutter side so the same
// input always produces the same key (used as a Firestore query key and as
// the guest_fcm_tokens document id). Returns digits only, no leading '+'.
//   1. Eastern-Arabic / Persian digits → ascii.
//   2. Strip whitespace, dashes, parentheses.
//   3. "00<cc>" → "+<cc>", then drop the leading '+'.
//   4. Saudi local  "05xxxxxxxx" / "5xxxxxxxxx"  → "9665xxxxxxxxx".
//   5. Egyptian local "01xxxxxxxxx" / "1xxxxxxxxxx" → "201xxxxxxxxxx".
function normalizePhone(input) {
    var value = String(input || '').trim();
    value = value
        .replace(/[٠-٩]/g, function(d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); })
        .replace(/[۰-۹]/g, function(d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); })
        .replace(/[\s\-()]/g, '');
    if (!value) return '';
    if (value.indexOf('00') === 0) value = '+' + value.slice(2);
    if (value[0] === '+') return value.slice(1).replace(/\D/g, '');
    var digits = value.replace(/\D/g, '');
    if (/^05\d{8}$/.test(digits)) return '966' + digits.slice(1);
    if (/^5\d{8}$/.test(digits)) return '966' + digits;
    if (/^01\d{9}$/.test(digits)) return '20' + digits.slice(1);
    if (/^1\d{9}$/.test(digits)) return '20' + digits;
    return digits;
}

module.exports = {
    getBearerToken: getBearerToken,
    parseBody: parseBody,
    jsonError: jsonError,
    stringData: stringData,
    normalizePhone: normalizePhone,
};
