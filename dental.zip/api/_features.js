function normalizePlan(plan) {
    var p = String(plan || 'basic').trim().toLowerCase();
    if (p === 'vip') return 'elite';
    if (p === 'elite' || p === 'pro') return p;
    return 'basic';
}

function getFeaturesForPlan(plan) {
    var p = normalizePlan(plan);
    var base = {
        patient_app_basic: true,
        appointments_management: true,
        basic_notifications: true,
        live_chat: false,
        clinic_map: false,
        medical_photos: false,
        doctor_photo_reply: false,
        faq_bot: false,
        patient_visit_summary: false,
        appointment_reminders: false,
        session_revenue_recording: false,
        whatsapp_direct: false,
        video_consultation: false,
        clinic_branding: false,
        white_label_experience: false,
        doctor_mobile_dashboard: false,
        advanced_revenue_analytics: false,
        treatments: false,
        analytics: false,
        service_price_list: false,
    };

    if (p === 'pro' || p === 'elite') {
        base.live_chat = true;
        base.clinic_map = true;
        base.medical_photos = true;
        base.doctor_photo_reply = true;
        base.faq_bot = true;
        base.patient_visit_summary = true;
        base.appointment_reminders = true;
        base.session_revenue_recording = true;
        base.whatsapp_direct = true;
        base.treatments = true;
        base.analytics = true;
        base.service_price_list = true;
    }

    if (p === 'elite') {
        base.video_consultation = true;
        base.clinic_branding = true;
        base.white_label_experience = true;
        base.doctor_mobile_dashboard = true;
        base.advanced_revenue_analytics = true;
    }

    return base;
}

function planFromClinicData(clinicData) {
    var subscription = clinicData && clinicData.subscription ? clinicData.subscription : {};
    return normalizePlan(subscription.plan || clinicData.plan || 'basic');
}

function hasFeature(clinicData, featureKey) {
    return getFeaturesForPlan(planFromClinicData(clinicData))[featureKey] === true;
}

function requiredPlanForFeature(featureKey) {
    if (featureKey === 'video_consultation') return 'elite';
    if (featureKey === 'whatsapp_direct') return 'pro';
    if (
        featureKey === 'session_revenue_recording' ||
        featureKey === 'appointment_reminders' ||
        featureKey === 'live_chat' ||
        featureKey === 'medical_photos' ||
        featureKey === 'doctor_photo_reply'
    ) return 'pro';
    return 'basic';
}

async function assertClinicFeature(db, clinicId, featureKey) {
    var snap = await db.collection('clinics').doc(clinicId).get();
    var clinicData = snap.exists ? snap.data() || {} : {};
    if (!hasFeature(clinicData, featureKey)) {
        var err = new Error('This feature is not available on your current plan.');
        err.httpStatus = 403;
        err.code = 'FEATURE_NOT_ALLOWED';
        err.requiredPlan = requiredPlanForFeature(featureKey);
        throw err;
    }
    return clinicData;
}

module.exports = {
    normalizePlan: normalizePlan,
    getFeaturesForPlan: getFeaturesForPlan,
    hasFeature: hasFeature,
    requiredPlanForFeature: requiredPlanForFeature,
    assertClinicFeature: assertClinicFeature,
};
