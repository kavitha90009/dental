// Vercel Serverless Function — CommonJS format (required by Vercel Node runtime).
// Set these in Vercel Dashboard → Project Settings → Environment Variables.
// NEVER hardcode keys here or in any file committed to git.
module.exports = function handler(req, res) {
    const required = [
        'FIREBASE_API_KEY',
        'FIREBASE_AUTH_DOMAIN',
        'FIREBASE_PROJECT_ID',
        'FIREBASE_STORAGE_BUCKET',
        'FIREBASE_MESSAGING_SENDER_ID',
        'FIREBASE_APP_ID',
    ];

    const missing = required.filter(function(k) { return !process.env[k]; });
    if (missing.length) {
        return res.status(500).json({ error: 'Server misconfigured', missing: missing });
    }

    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Content-Type', 'application/json');
    res.status(200).json({
        apiKey:            process.env.FIREBASE_API_KEY,
        authDomain:        process.env.FIREBASE_AUTH_DOMAIN,
        projectId:         process.env.FIREBASE_PROJECT_ID,
        storageBucket:     process.env.FIREBASE_STORAGE_BUCKET,
        messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
        appId:             process.env.FIREBASE_APP_ID,
        measurementId:     process.env.FIREBASE_MEASUREMENT_ID || '',
    });
};
