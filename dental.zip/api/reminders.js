// Appointment Reminder Engine - Vercel Cron Job
// Sends appointment reminders for the current appointment model:
//   appointments.status == "scheduled"
//   appointments.date + appointments.time are interpreted in Asia/Riyadh.
//
// Required environment:
//   FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY
//   CRON_SECRET

var admin = require('firebase-admin');

if (!admin.apps.length) {
    var privateKey = (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
    admin.initializeApp({
        credential: admin.credential.cert({
            projectId: process.env.FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey: privateKey,
        }),
    });
}

var db = admin.firestore();
var messaging = admin.messaging();
// Default timezone for the cron's query window. Per-clinic timezone is
// applied per-appointment via clinicTimezoneCache below — Saudi clinics
// keep current behavior; non-Saudi clinics get their own wall-clock math.
var TZ = 'Asia/Riyadh';
var hasFeature = require('./_features').hasFeature;
var clinicFeatureCache = {};
var clinicTimezoneCache = {};
var SUPPORTED_TIMEZONES = new Set([
    'Asia/Riyadh', 'Africa/Cairo', 'Asia/Dubai', 'Asia/Amman',
    'Asia/Kuwait', 'Asia/Bahrain', 'Asia/Qatar', 'Asia/Muscat',
]);

var _utils = require('./_utils');
var getBearerToken = _utils.getBearerToken;
var normalizePhone = _utils.normalizePhone;
var stringData     = _utils.stringData;

function verifyCronSecret(req) {
    var expected = process.env.CRON_SECRET;
    if (!expected) {
        console.error('[reminders] rejected: CRON_SECRET is not configured');
        return { ok: false, status: 500, error: 'cron secret not configured' };
    }

    var provided = getBearerToken(req.headers.authorization) || req.headers['x-cron-secret'] || '';
    if (provided !== expected) {
        console.warn('[reminders] rejected: invalid cron secret');
        return { ok: false, status: 401, error: 'unauthorized' };
    }

    return { ok: true };
}

function clinicParts(date, timezone) {
    var tz = SUPPORTED_TIMEZONES.has(timezone) ? timezone : TZ;
    var formatter = new Intl.DateTimeFormat('en-CA', {
        timeZone: tz,
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        hourCycle: 'h23',
    });
    var parts = {};
    formatter.formatToParts(date).forEach(function(part) {
        if (part.type !== 'literal') parts[part.type] = part.value;
    });
    return {
        year: Number(parts.year),
        month: Number(parts.month),
        day: Number(parts.day),
        hour: Number(parts.hour),
        minute: Number(parts.minute),
    };
}
function riyadhParts(date) { return clinicParts(date, TZ); }

function dateStringFromParts(parts) {
    return [
        String(parts.year).padStart(4, '0'),
        String(parts.month).padStart(2, '0'),
        String(parts.day).padStart(2, '0'),
    ].join('-');
}

function addDaysToRiyadhDate(parts, days) {
    var d = new Date(Date.UTC(parts.year, parts.month - 1, parts.day + days, 12, 0, 0));
    return riyadhParts(d);
}

function parseTime(time) {
    var raw = String(time || '').trim();
    var match = raw.match(/^(\d{1,2}):(\d{2})/);
    if (!match) return null;
    var hour = Number(match[1]);
    var minute = Number(match[2]);
    if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
    return { hour: hour, minute: minute };
}

function localWallClockMs(dateStr, timeStr) {
    var dateMatch = String(dateStr || '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
    var time = parseTime(timeStr);
    if (!dateMatch || !time) return null;
    return Date.UTC(
        Number(dateMatch[1]),
        Number(dateMatch[2]) - 1,
        Number(dateMatch[3]),
        time.hour,
        time.minute,
        0,
        0
    );
}

function nowRiyadhWallClockMs() {
    var now = riyadhParts(new Date());
    return Date.UTC(now.year, now.month - 1, now.day, now.hour, now.minute, 0, 0);
}

function nowClinicWallClockMs(timezone) {
    var now = clinicParts(new Date(), timezone);
    return Date.UTC(now.year, now.month - 1, now.day, now.hour, now.minute, 0, 0);
}

function targetDatesForQuery() {
    // Widen window to cover clinics whose local "today" differs from Riyadh's
    // (Egypt UTC+2 vs Riyadh UTC+3 can push date boundary by 1 day around
    // midnight). Three consecutive Riyadh dates safely cover GCC + Egypt.
    var today = riyadhParts(new Date());
    var yesterday = addDaysToRiyadhDate(today, -1);
    var tomorrow = addDaysToRiyadhDate(today, 1);
    return [
        dateStringFromParts(yesterday),
        dateStringFromParts(today),
        dateStringFromParts(tomorrow),
    ];
}

function isInWindow(minutesUntil, centerMinutes, toleranceMinutes) {
    return minutesUntil >= centerMinutes - toleranceMinutes &&
        minutesUntil <= centerMinutes + toleranceMinutes;
}

async function getPatientToken(patientUid) {
    if (!patientUid) return '';
    var snap = await db.collection('patients_app').doc(patientUid).get();
    if (!snap.exists) return '';
    return snap.data().fcmToken || '';
}

// Canonical digits-only form. Must match patient app + appointment-action.js
// + complete-session.js so a guest's FCM token is always looked up at the
// same Firestore key.
// normalizePhone is imported from ./_utils above.

async function getGuestToken(phone) {
    if (!phone) return '';
    var key = normalizePhone(phone);
    if (!key) return '';
    var snap = await db.collection('guest_fcm_tokens').doc(key).get();
    if (!snap.exists) return '';
    return snap.data().fcmToken || '';
}

async function sendPush(token, title, body, data) {
    await messaging.send({
        token: token,
        notification: { title: title, body: body },
        data: stringData(data),
        android: {
            priority: 'high',
            notification: {
                channelId: 'appointments',
                sound: 'default',
                priority: 'high',
            },
        },
    });
}

async function clinicAllowsReminders(clinicId) {
    if (!clinicId) return false;
    if (clinicFeatureCache[clinicId] !== undefined) return clinicFeatureCache[clinicId];
    var snap = await db.collection('clinics').doc(clinicId).get();
    var data = snap.exists ? (snap.data() || {}) : {};
    var allowed = snap.exists && hasFeature(data, 'appointment_reminders');
    clinicFeatureCache[clinicId] = allowed;
    clinicTimezoneCache[clinicId] = (data.timezone && SUPPORTED_TIMEZONES.has(data.timezone)) ? data.timezone : TZ;
    return allowed;
}

async function sendReminder(doc, appt, kind, counters) {
    var reminders = appt.reminders || {};
    var sentKey = kind === '24h' ? 'sent24h' : 'sent1h';
    var sentAtKey = kind === '24h' ? 'sent24hAt' : 'sent1hAt';

    if (reminders[sentKey] || appt['reminder' + kind + 'SentAt']) {
        counters.skippedAlreadySent++;
        return;
    }

    var token = appt.patientUid
        ? await getPatientToken(appt.patientUid)
        : await getGuestToken(appt.guestPhone || appt.patientPhone || '');
    if (!token) {
        counters.skippedNoToken++;
        return;
    }

    var title = kind === '24h' ? 'Appointment reminder: tomorrow' : 'Appointment in one hour';
    var body = kind === '24h'
        ? 'You have an appointment at the clinic tomorrow. Please review the appointment details in the app.'
        : 'Reminder: your appointment at the clinic is in one hour.';
    var type = kind === '24h' ? 'appointment_reminder_24h' : 'appointment_reminder_1h';

    await sendPush(token, title, body, {
        type: type,
        appointmentId: doc.id,
        clinicId: appt.clinicId || '',
    });

    var update = {
        remindersUpdatedAt: admin.firestore.FieldValue.serverTimestamp(),
    };
    update['reminders.' + sentKey] = true;
    update['reminders.' + sentAtKey] = admin.firestore.FieldValue.serverTimestamp();

    await doc.ref.update(update);

    if (kind === '24h') counters.sent24h++;
    if (kind === '1h') counters.sent1h++;
}

async function processAppointment(doc, counters) {
    counters.checked++;
    var appt = doc.data();

    if (appt.status !== 'scheduled') return;
    if (!appt.clinicId) return;
    if (!(await clinicAllowsReminders(appt.clinicId))) {
        counters.skippedPlan++;
        return;
    }

    var scheduledMs = localWallClockMs(appt.date, appt.time);
    if (scheduledMs === null) return;

    // Use clinic's own timezone for "now" so reminders fire at the right
    // wall-clock moment for each clinic. Saudi clinics fall back to TZ.
    var clinicTz = clinicTimezoneCache[appt.clinicId] || TZ;
    var minutesUntil = Math.round((scheduledMs - nowClinicWallClockMs(clinicTz)) / 60000);
    var tasks = [];

    if (isInWindow(minutesUntil, 24 * 60, 65)) {
        tasks.push(sendReminder(doc, appt, '24h', counters));
    }
    if (isInWindow(minutesUntil, 60, 65)) {
        tasks.push(sendReminder(doc, appt, '1h', counters));
    }

    var results = await Promise.allSettled(tasks);
    results.forEach(function(result) {
        if (result.status === 'rejected') {
            counters.failed++;
            console.warn('[reminders] reminder failed for appointment', doc.id, result.reason && result.reason.message);
        }
    });
}

// Drain the pending_guest_notifications queue populated by
// appointment-action.js when a guest's FCM token wasn't yet saved at the
// moment a notification fired. For each pending doc we retry with the
// current token; on success we delete the doc, on persistent failure we
// give up after a few attempts or 7 days.
async function flushPendingGuestNotifications(counters) {
    var SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;
    var MAX_ATTEMPTS  = 12;
    var snap;
    try {
        snap = await db.collection('pending_guest_notifications').limit(200).get();
    } catch (err) {
        console.warn('[pending-guest-notif] read failed:', err && err.message);
        return;
    }
    var tasks = [];
    snap.forEach(function(doc) {
        var data = doc.data() || {};
        var phoneKey = String(data.normalizedPhone || '').replace(/\D/g, '');
        var attempts = Number(data.attempts || 0);
        var createdAt = data.createdAt && data.createdAt.toMillis ? data.createdAt.toMillis() : 0;
        var ageOk = !createdAt || (Date.now() - createdAt < SEVEN_DAYS_MS);
        if (!phoneKey || !ageOk || attempts >= MAX_ATTEMPTS) {
            counters.dropped++;
            tasks.push(doc.ref.delete().catch(function() {}));
            return;
        }
        tasks.push((async function() {
            var tokenSnap;
            try {
                tokenSnap = await db.collection('guest_fcm_tokens').doc(phoneKey).get();
            } catch (err) {
                counters.failed++;
                return;
            }
            if (!tokenSnap.exists) {
                counters.stillNoToken++;
                await doc.ref.update({
                    attempts: attempts + 1,
                    lastTriedAt: admin.firestore.FieldValue.serverTimestamp(),
                }).catch(function() {});
                return;
            }
            var token = tokenSnap.data().fcmToken;
            if (!token) {
                counters.stillNoToken++;
                await doc.ref.update({
                    attempts: attempts + 1,
                    lastTriedAt: admin.firestore.FieldValue.serverTimestamp(),
                }).catch(function() {});
                return;
            }
            try {
                await sendPush(
                    token,
                    String(data.title || ''),
                    String(data.body  || ''),
                    data.data || {}
                );
                counters.delivered++;
                await doc.ref.delete().catch(function() {});
            } catch (err) {
                counters.failed++;
                await doc.ref.update({
                    attempts: attempts + 1,
                    lastTriedAt: admin.firestore.FieldValue.serverTimestamp(),
                    lastError: (err && err.message) || 'unknown',
                }).catch(function() {});
            }
        })());
    });
    await Promise.allSettled(tasks);
}

async function processScheduledReminders() {
    var counters = {
        checked: 0,
        sent24h: 0,
        sent1h: 0,
        skippedNoToken: 0,
        skippedAlreadySent: 0,
        skippedPlan: 0,
        failed: 0,
    };

    var snap = await db.collection('appointments')
        .where('status', '==', 'scheduled')
        .where('date', 'in', targetDatesForQuery())
        .get();

    var tasks = [];
    snap.forEach(function(doc) {
        tasks.push(processAppointment(doc, counters));
    });

    var results = await Promise.allSettled(tasks);
    results.forEach(function(result) {
        if (result.status === 'rejected') {
            counters.failed++;
            console.warn('[reminders] appointment processing failed:', result.reason && result.reason.message);
        }
    });

    return counters;
}

module.exports = async function handler(req, res) {
    if (req.method !== 'GET' && req.method !== 'POST') {
        return res.status(405).json({ error: 'Method Not Allowed' });
    }

    var secretCheck = verifyCronSecret(req);
    if (!secretCheck.ok) {
        return res.status(secretCheck.status).json({ error: secretCheck.error });
    }

    try {
        var counters = await processScheduledReminders();
        var queue = { delivered: 0, stillNoToken: 0, dropped: 0, failed: 0 };
        try {
            await flushPendingGuestNotifications(queue);
        } catch (qErr) {
            console.warn('[pending-guest-notif] flush failed:', qErr && qErr.message);
        }
        return res.status(200).json({
            ok: true,
            checked: counters.checked,
            sent24h: counters.sent24h,
            sent1h: counters.sent1h,
            skippedNoToken: counters.skippedNoToken,
            skippedAlreadySent: counters.skippedAlreadySent,
            skippedPlan: counters.skippedPlan,
            failed: counters.failed,
            queue: queue,
        });
    } catch (err) {
        console.error('[reminders] error:', err.message);
        return res.status(500).json({ ok: false, error: 'reminder processing failed' });
    }
};
