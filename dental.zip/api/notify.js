// =============================================================================
// /api/notify — consolidated notification + tracking endpoint
// =============================================================================
//
// This single Vercel function serves THREE concerns, dispatched by HTTP
// method and POST body shape. They are folded together to stay inside the
// Vercel Hobby 12-function deployment cap.
//
//   GET  /api/notify           → 1×1 email open tracking pixel
//                                 (also reachable as /api/track/open via rewrite)
//   HEAD /api/notify           → pixel headers only, no Firestore write
//   POST /api/notify           → FCM push to a patient by patientId
//                                 auth: NOTIFY_API_SECRET (server-to-server)
//                                 body: { patientId, title, body, data? }
//   POST /api/notify           → patient-notification-action (dashboard)
//                                 (also reachable as /api/patient-notification-action via rewrite)
//                                 auth: Firebase ID token (Authorization: Bearer)
//                                 body: { action, clinicId, patientUid, ... }
//
// Body-shape dispatch: a POST that carries `action + clinicId + patientUid`
// is treated as the patient-notification-action flow; otherwise it is the
// secret-authenticated FCM push flow.
// =============================================================================

var admin  = require('firebase-admin');
var crypto = require('crypto');
var assertClinicFeature = require('./_features').assertClinicFeature;

if (!admin.apps.length) {
    var privateKey = (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
    admin.initializeApp({
        credential: admin.credential.cert({
            projectId:   process.env.FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey:  privateKey,
        }),
    });
}

var db = admin.firestore();

// ─────────────────────────────────────────────────────────────────────────────
// Email open tracking pixel (GET / HEAD)
// ─────────────────────────────────────────────────────────────────────────────
var TRACKING_PIXEL = Buffer.from(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=',
    'base64'
);

// Per-deployment salt for hashing IPs in open-tracking analytics. No
// hardcoded salt ships in source — set IP_HASH_SALT in your environment
// (see api/.env.example). An unsalted hash of a short value like an IP is
// trivially reversible with a rainbow table, so set this in production.
var IP_HASH_SALT = process.env.IP_HASH_SALT || '';
function hashIP(ip) {
    if (!ip) return null;
    return crypto.createHash('sha256')
                 .update(String(ip) + IP_HASH_SALT)
                 .digest('hex').slice(0, 12);
}

async function serveTrackingPixel(req, res) {
    var q        = req.query || {};
    var doctorId = q.d ? String(q.d) : '';
    var emailNum = q.e ? String(q.e) : '';

    // Log BEFORE flushing — Vercel may freeze the function the moment
    // res.send returns, so trailing awaits aren't reliable. Wrapped in
    // try/catch: a write failure must never break the pixel.
    if (doctorId) {
        try {
            var ref = db.collection('outreach_tracking').doc(doctorId);
            await ref.collection('email_opens').add({
                email_num:  parseInt(emailNum, 10) || null,
                opened_at:  admin.firestore.FieldValue.serverTimestamp(),
                user_agent: req.headers['user-agent'] || null,
                referer:    req.headers['referer'] || req.headers['referrer'] || null,
                ip_hash:    hashIP(req.headers['x-forwarded-for'] || ''),
            });
            await ref.set({
                last_active_at:    admin.firestore.FieldValue.serverTimestamp(),
                total_email_opens: admin.firestore.FieldValue.increment(1),
            }, { merge: true });
        } catch (err) {
            console.error('[track/open] log failed:', err && err.message);
        }
    }

    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    res.status(200).send(TRACKING_PIXEL);
}

// ─────────────────────────────────────────────────────────────────────────────
// Shared helpers
// ─────────────────────────────────────────────────────────────────────────────
var _utils = require('./_utils');
var getBearerToken = _utils.getBearerToken;
var parseBody      = _utils.parseBody;
var jsonError      = _utils.jsonError;
var stringData     = _utils.stringData;

// ─────────────────────────────────────────────────────────────────────────────
// POST flow A — FCM push (server-to-server, NOTIFY_API_SECRET auth)
// ─────────────────────────────────────────────────────────────────────────────
async function handleFcmPush(req, res, body) {
    var expectedSecret = process.env.NOTIFY_API_SECRET;
    if (!expectedSecret) {
        console.warn('[notify] rejected: NOTIFY_API_SECRET is not configured');
        return res.status(503).json({ error: 'notify api is not configured' });
    }
    var providedSecret = req.headers['x-notify-secret'] ||
                         getBearerToken(req.headers.authorization);
    if (providedSecret !== expectedSecret) {
        console.warn('[notify] rejected: invalid notify secret');
        return res.status(401).json({ error: 'unauthorized' });
    }

    var patientId = body.patientId;
    var title     = body.title || 'DentalSuite Dental';
    var bodyText  = body.body  || '';
    var data      = body.data  || {};

    if (!patientId) return res.status(400).json({ error: 'missing patientId' });

    try {
        var snap = await db.collection('patients_app').doc(patientId).get();
        if (!snap.exists) {
            return res.status(200).json({ sent: false, reason: 'patient_not_found' });
        }
        var token = snap.data().fcmToken;
        if (!token) {
            console.log('[notify] no FCM token for patient:', patientId);
            return res.status(200).json({ sent: false, reason: 'no_token' });
        }

        await admin.messaging().send({
            token: token,
            notification: { title: title, body: bodyText },
            data: stringData(data),
            android: {
                priority: 'high',
                notification: { channelId: 'appointments', sound: 'default', priority: 'high' },
            },
        });

        console.log('[notify] sent to patient:', patientId, '| title:', title);
        return res.status(200).json({ sent: true });
    } catch (err) {
        console.error('[notify] error:', err.message);
        return res.status(500).json({ error: err.message });
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// POST flow B — patient-notification-action (dashboard, Firebase ID token)
// (folded from the deleted /api/patient-notification-action.js)
// ─────────────────────────────────────────────────────────────────────────────
async function loadPatientForClinic(patientUid, clinicId) {
    if (!patientUid || !clinicId) {
        var missing = new Error('patientUid and clinicId are required');
        missing.httpStatus = 400; missing.code = 'MISSING_FIELDS';
        throw missing;
    }
    var snap = await db.collection('patients_app').doc(patientUid).get();
    if (!snap.exists) {
        var notFound = new Error('patient not found');
        notFound.httpStatus = 404; notFound.code = 'PATIENT_NOT_FOUND';
        throw notFound;
    }
    var patient = snap.data() || {};
    // In the new model a patients_app doc carries linkedClinics[clinicId];
    // older docs may still have the flat `clinicId` field. Accept either.
    var linkedHere = (patient.linkedClinics && patient.linkedClinics[clinicId]) ||
                     patient.clinicId === clinicId;
    if (!linkedHere) {
        var wrongClinic = new Error('patient does not belong to this clinic');
        wrongClinic.httpStatus = 403; wrongClinic.code = 'PATIENT_CLINIC_MISMATCH';
        throw wrongClinic;
    }
    return patient;
}

async function sendPatientNotification(patientUid, patient, title, body, data) {
    var token = patient.fcmToken || '';
    if (!token) return { sent: false, reason: 'NO_FCM_TOKEN' };
    await admin.messaging().send({
        token: token,
        notification: { title: title, body: body },
        data: stringData(data),
        android: {
            priority: 'high',
            notification: { channelId: 'appointments', sound: 'default', priority: 'high' },
        },
    });
    return { sent: true };
}

async function handlePatientNotificationAction(req, res, body) {
    var token = getBearerToken(req.headers.authorization);
    if (!token) return jsonError(res, 401, 'MISSING_TOKEN', 'Missing Firebase ID token');

    var decoded;
    try {
        decoded = await admin.auth().verifyIdToken(token);
    } catch (err) {
        return jsonError(res, 401, 'INVALID_TOKEN', 'Invalid Firebase ID token');
    }

    var action     = body.action || '';
    var clinicId   = body.clinicId || '';
    var patientUid = body.patientUid || '';

    if (!clinicId || decoded.uid !== clinicId) {
        return jsonError(res, 403, 'CLINIC_MISMATCH', 'Token uid does not match clinicId');
    }

    try {
        var feature = action === 'doctor_photo_reply' ? 'doctor_photo_reply' : 'live_chat';
        await assertClinicFeature(db, clinicId, feature);
        var patient = await loadPatientForClinic(patientUid, clinicId);
        var notification;

        if (action === 'chat_message') {
            notification = await sendPatientNotification(
                patientUid, patient,
                'New message from the clinic',
                'You have a new message from the clinic.',
                { type: 'chat_message', patientUid: patientUid, clinicId: clinicId }
            );
        } else if (action === 'doctor_photo_reply') {
            notification = await sendPatientNotification(
                patientUid, patient,
                'Doctor replied to your case photo',
                'The doctor added a reply to your medical photo.',
                { type: 'doctor_photo_reply', patientUid: patientUid,
                  clinicId: clinicId, photoId: body.photoId || '' }
            );
        } else {
            return jsonError(res, 400, 'INVALID_ACTION', 'Unsupported notification action');
        }

        return res.status(200).json({
            success: true, ok: true, action: action,
            notificationSent: notification.sent === true,
            notificationReason: notification.reason,
        });
    } catch (err) {
        var status = err.httpStatus || 500;
        var code   = err.code || 'INTERNAL_ERROR';
        console.error('[patient-notification-action]', code, err.message);
        return jsonError(res, status, code, err.message, err.requiredPlan);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Top-level handler — dispatch
// ─────────────────────────────────────────────────────────────────────────────
module.exports = async function handler(req, res) {
    if (req.method === 'GET') return serveTrackingPixel(req, res);

    if (req.method === 'HEAD') {
        res.setHeader('Content-Type', 'image/png');
        res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
        res.setHeader('Pragma', 'no-cache');
        res.setHeader('Expires', '0');
        return res.status(200).end();
    }

    if (req.method !== 'POST') return res.status(405).end();

    var body = parseBody(req.body);

    // Body-shape dispatch: dashboard's patient-notification-action carries
    // { action, clinicId, patientUid }. The legacy FCM push carries patientId.
    if (body.action && body.clinicId && body.patientUid) {
        return handlePatientNotificationAction(req, res, body);
    }
    return handleFcmPush(req, res, body);
};
