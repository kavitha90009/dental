// Secure appointment request actions for clinic dashboard.
// Auth: Firebase ID token in Authorization: Bearer <token>.

var admin = require('firebase-admin');

if (!admin.apps.length) {
    var privateKey = (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
    admin.initializeApp({
        credential: admin.credential.cert({
            projectId:   process.env.FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey:  privateKey,
        }),
    });
}

var db = admin.firestore();
var FieldValue = admin.firestore.FieldValue;
var assertClinicFeature = require('./_features').assertClinicFeature;

function cleanUndefined(obj) {
    return Object.fromEntries(Object.entries(obj).filter(function(entry) {
        return entry[1] !== undefined;
    }));
}

var _utils = require('./_utils');
var getBearerToken = _utils.getBearerToken;
var parseBody      = _utils.parseBody;
var jsonError      = _utils.jsonError;
var normalizePhone = _utils.normalizePhone;
var stringData     = _utils.stringData;

async function sendPatientNotification(patientUid, title, body, data) {
    if (!patientUid) return { sent: false, reason: 'missing_patient_uid' };
    var snap = await db.collection('patients_app').doc(patientUid).get();
    if (!snap.exists) return { sent: false, reason: 'patient_not_found' };
    var token = snap.data().fcmToken;
    if (!token) return { sent: false, reason: 'no_token' };

    await admin.messaging().send({
        token: token,
        notification: { title: title, body: body },
        data: stringData(data),
        android: {
            priority: 'high',
            notification: {
                channelId: 'appointments',
                sound: 'default',
                priority: 'high',
            },
        },
    });
    return { sent: true };
}

async function sendGuestNotification(phone, title, body, data) {
    var key = normalizePhone(phone).replace(/\D/g, '');
    if (!key) return { sent: false, reason: 'missing_phone' };
    var snap = await db.collection('guest_fcm_tokens').doc(key).get();
    if (!snap.exists) {
        await enqueuePendingGuestNotification(key, title, body, data, 'no_guest_token');
        return { sent: false, reason: 'no_guest_token', queued: true };
    }
    var token = snap.data().fcmToken;
    if (!token) {
        await enqueuePendingGuestNotification(key, title, body, data, 'no_guest_token');
        return { sent: false, reason: 'no_guest_token', queued: true };
    }

    await admin.messaging().send({
        token: token,
        notification: { title: title, body: body },
        data: stringData(data),
        android: {
            priority: 'high',
            notification: {
                channelId: 'appointments',
                sound: 'default',
                priority: 'high',
            },
        },
    });
    return { sent: true };
}

// Stores a pending notification so the reminders cron can retry it
// once the guest's FCM token finally lands in guest_fcm_tokens/{key}.
// Best-effort: if the write itself fails we don't break the caller.
async function enqueuePendingGuestNotification(normalizedKey, title, body, data, reason) {
    try {
        await db.collection('pending_guest_notifications').add({
            normalizedPhone: normalizedKey,
            title: String(title || ''),
            body:  String(body  || ''),
            data:  stringData(data || {}),
            attempts: 0,
            reason: reason || '',
            createdAt: FieldValue.serverTimestamp(),
            lastTriedAt: null,
        });
    } catch (err) {
        console.warn('[pending-guest-notif] failed to enqueue:', err && err.message);
    }
}

// jsonError / parseBody / normalizePhone are imported from ./_utils above.

function appendNote(existing, note) {
    if (!note) return existing || '';
    var current = String(existing || '').trim();
    if (!current) return note;
    if (current.indexOf(note) !== -1) return current;
    return current + '\n' + note;
}

async function approveRequest(requestId, clinicId, actorUid) {
    var result = await db.runTransaction(async function(tx) {
        var reqRef = db.collection('appointment_requests').doc(requestId);
        var reqSnap = await tx.get(reqRef);
        if (!reqSnap.exists) {
            var notFound = new Error('request not found');
            notFound.httpStatus = 404;
            notFound.code = 'request_not_found';
            throw notFound;
        }

        var request = reqSnap.data() || {};
        if (request.clinicId !== clinicId) {
            var wrongClinic = new Error('wrong clinic');
            wrongClinic.httpStatus = 403;
            wrongClinic.code = 'wrong_clinic';
            throw wrongClinic;
        }
        if (request.status !== 'pending' && request.status !== 'pending_review') {
            var notPending = new Error('request is not pending');
            notPending.httpStatus = 400;
            notPending.code = 'request_not_pending';
            throw notPending;
        }
        if (!request.patientUid && !request.bookedByUid && !request.patientPhone && !request.phone) {
            var missingPatient = new Error('missing patient contact');
            missingPatient.httpStatus = 400;
            missingPatient.code = 'missing_patient_contact';
            throw missingPatient;
        }

        var notificationUid = request.bookedByUid || request.patientUid || '';
        var requestPatientUid = request.patientUid || '';
        var patientAppRef = notificationUid ? db.collection('patients_app').doc(notificationUid) : null;
        var patientAppSnap = patientAppRef ? await tx.get(patientAppRef) : null;
        var patientApp = patientAppSnap && patientAppSnap.exists ? patientAppSnap.data() || {} : {};

        var isForSomeoneElse = request.isForSomeoneElse === true;
        var patientsSnap = { empty: true, docs: [] };
        if (!isForSomeoneElse && requestPatientUid) {
            var patientsQuery = db.collection('patients')
                .where('clinicId', '==', clinicId)
                .where('patientUid', '==', requestPatientUid)
                .limit(1);
            patientsSnap = await tx.get(patientsQuery);
        }
        var patientPhone = isForSomeoneElse
            ? (request.patientPhone || request.phone || '')
            : (request.patientPhone || request.phone || patientApp.phone || '');
        var normalizedPhone = normalizePhone(patientPhone);
        var patientName = isForSomeoneElse && request.patientName
            ? request.patientName
            : (patientApp.name || request.patientName || 'App patient');
        var phonePatientsSnap = null;
        if (patientsSnap.empty && isForSomeoneElse && normalizedPhone && patientName) {
            phonePatientsSnap = await tx.get(db.collection('patients')
                .where('clinicId', '==', clinicId)
                .where('normalizedPhone', '==', normalizedPhone)
                .where('name', '==', patientName)
                .limit(1));
        }
        if (patientsSnap.empty && (!phonePatientsSnap || phonePatientsSnap.empty) && normalizedPhone) {
            phonePatientsSnap = await tx.get(db.collection('patients')
                .where('clinicId', '==', clinicId)
                .where('normalizedPhone', '==', normalizedPhone)
                .limit(1));
        }
        if (patientsSnap.empty && (!phonePatientsSnap || phonePatientsSnap.empty) && patientPhone) {
            phonePatientsSnap = await tx.get(db.collection('patients')
                .where('clinicId', '==', clinicId)
                .where('phone', '==', patientPhone)
                .limit(1));
        }
        var emailPatientsSnap = null;
        var patientEmail = !isForSomeoneElse ? (patientApp.email || request.patientEmail || request.email || '') : (request.patientEmail || request.email || '');
        if (patientsSnap.empty && (!phonePatientsSnap || phonePatientsSnap.empty) && patientEmail) {
            emailPatientsSnap = await tx.get(db.collection('patients')
                .where('clinicId', '==', clinicId)
                .where('email', '==', patientEmail)
                .limit(1));
        }

        var patientId;
        var bookedByName = request.bookedByName || patientApp.name || request.patientName || '';
        var bookedByPhone = request.bookedByPhone || patientApp.phone || request.patientPhone || request.phone || '';
        var familyBookingNote = isForSomeoneElse
            ? 'Booked by ' + (bookedByName || 'app user') + (request.relationship ? ' for relative: ' + request.relationship : '')
            : '';
        var actualPatientUid;
        if (!patientsSnap.empty || (phonePatientsSnap && !phonePatientsSnap.empty) || (emailPatientsSnap && !emailPatientsSnap.empty)) {
            var patientDoc = !patientsSnap.empty
                ? patientsSnap.docs[0]
                : (phonePatientsSnap && !phonePatientsSnap.empty ? phonePatientsSnap.docs[0] : emailPatientsSnap.docs[0]);
            var existingPatient = patientDoc.data() || {};
            patientId = patientDoc.id;
            actualPatientUid = !isForSomeoneElse ? (requestPatientUid || existingPatient.patientUid) : existingPatient.patientUid;
            tx.set(patientDoc.ref, cleanUndefined({
                patientUid: actualPatientUid,
                phone: existingPatient.phone || patientPhone,
                normalizedPhone: existingPatient.normalizedPhone || normalizedPhone || undefined,
                email: existingPatient.email || patientEmail || undefined,
                notes: isForSomeoneElse ? appendNote(existingPatient.notes, familyBookingNote) : existingPatient.notes,
                linkedAt: FieldValue.serverTimestamp(),
                updatedAt: FieldValue.serverTimestamp(),
            }), { merge: true });
            patientName = patientName || existingPatient.name || 'App patient';
        } else {
            var patientRef = db.collection('patients').doc();
            patientId = patientRef.id;
            actualPatientUid = !isForSomeoneElse && requestPatientUid ? requestPatientUid : undefined;
            tx.set(patientRef, cleanUndefined({
                clinicId: clinicId,
                patientUid: actualPatientUid,
                name: patientName,
                phone: patientPhone,
                normalizedPhone: normalizedPhone || undefined,
                email: patientEmail || '',
                gender: '',
                birthDate: '',
                notes: isForSomeoneElse
                    ? appendNote('Auto-created after accepting a booking request from the app', familyBookingNote)
                    : 'Auto-created after accepting a booking request from the app',
                source: 'patient_app',
                linkedAt: FieldValue.serverTimestamp(),
                createdAt: FieldValue.serverTimestamp(),
            }));
        }

        if (!isForSomeoneElse && patientAppRef) {
            tx.set(patientAppRef, cleanUndefined({
                linkedPatientId: patientId,
                phone: patientApp.phone || patientPhone,
                normalizedPhone: patientApp.normalizedPhone || normalizedPhone || undefined,
                email: patientApp.email || patientEmail || undefined,
                updatedAt: FieldValue.serverTimestamp(),
            }), { merge: true });
        }

        var apptRef = db.collection('appointments').doc();
        tx.set(apptRef, cleanUndefined({
            clinicId: clinicId,
            patientUid: actualPatientUid,
            patientId: patientId,
            patientName: patientName,
            phone: patientPhone,
            patientPhone: patientPhone,
            bookedByUid: notificationUid || undefined,
            bookedByName: bookedByName,
            bookedByPhone: bookedByPhone,
            isForSomeoneElse: isForSomeoneElse,
            relationship: request.relationship || '',
            date: request.date,
            time: request.time,
            duration: Number(request.duration || 30) || 30,
            type: request.type,
            notes: request.notes,
            status: 'scheduled',
            source: 'patient_request',
            requestId: requestId,
            createdAt: FieldValue.serverTimestamp(),
        }));

        tx.update(reqRef, cleanUndefined({
            status: 'approved',
            approvedAt: FieldValue.serverTimestamp(),
            approvedBy: actorUid,
            appointmentId: apptRef.id,
            patientId: patientId,
        }));

        return {
            requestId: requestId,
            appointmentId: apptRef.id,
            patientId: patientId,
            patientUid: actualPatientUid,
            notificationUid: notificationUid,
            patientPhone: patientPhone,
        };
    });

    var notification = { sent: false };
    var notifData = {
        type: 'appointment_request_approved',
        requestId: requestId,
        appointmentId: result.appointmentId,
        clinicId: clinicId,
    };
    try {
        if (result.notificationUid) {
            notification = await sendPatientNotification(
                result.notificationUid,
                'Appointment request accepted',
                'Your appointment request has been accepted. You can review the appointment details in the app.',
                notifData
            );
        }
        if (!notification.sent && result.patientPhone) {
            notification = await sendGuestNotification(
                result.patientPhone,
                'Appointment request accepted',
                'Your appointment request has been accepted. You can review the appointment details in the app.',
                notifData
            );
        }
    } catch (err) {
        notification = { sent: false, error: err.message };
    }
    if (notification && notification.sent === false) {
        console.warn('[notify] approve notification failed', {
            requestId: requestId,
            clinicId: clinicId,
            appointmentId: result.appointmentId,
            reason: notification.reason || 'unknown',
            error: notification.error || null,
        });
    }

    return {
        success: true,
        action: 'approve',
        requestId: requestId,
        appointmentId: result.appointmentId,
        patientId: result.patientId,
        notificationSent: notification.sent === true,
        notificationError: notification.error,
        notificationReason: notification.reason,
    };
}

async function rejectRequest(requestId, clinicId, actorUid, rejectionReason, rejectionNotes) {
    var result = await db.runTransaction(async function(tx) {
        var reqRef = db.collection('appointment_requests').doc(requestId);
        var reqSnap = await tx.get(reqRef);
        if (!reqSnap.exists) {
            var notFound = new Error('request not found');
            notFound.httpStatus = 404;
            notFound.code = 'request_not_found';
            throw notFound;
        }

        var request = reqSnap.data() || {};
        if (request.clinicId !== clinicId) {
            var wrongClinic = new Error('wrong clinic');
            wrongClinic.httpStatus = 403;
            wrongClinic.code = 'wrong_clinic';
            throw wrongClinic;
        }
        if (request.status !== 'pending' && request.status !== 'pending_review') {
            var notPending = new Error('request is not pending');
            notPending.httpStatus = 400;
            notPending.code = 'request_not_pending';
            throw notPending;
        }

        tx.update(reqRef, cleanUndefined({
            status: 'rejected',
            rejectionReason: rejectionReason,
            rejectionNotes: rejectionNotes,
            rejectedAt: FieldValue.serverTimestamp(),
            rejectedBy: actorUid,
        }));

        return {
            patientUid: request.bookedByUid || request.patientUid || null,
            patientPhone: request.patientPhone || request.phone || '',
        };
    });

    var notification = { sent: false };
    var rejectData = {
        type: 'appointment_request_rejected',
        requestId: requestId,
        clinicId: clinicId,
        rejectionReason: rejectionReason || '',
    };
    var rejectTitle = 'Appointment request declined';
    var rejectBody = rejectionReason
        ? 'Your appointment request was declined. Reason: ' + rejectionReason
        : 'Your appointment request was declined. You can choose another time in the app.';
    try {
        if (result.patientUid) {
            notification = await sendPatientNotification(result.patientUid, rejectTitle, rejectBody, rejectData);
        }
        if (!notification.sent && result.patientPhone) {
            notification = await sendGuestNotification(result.patientPhone, rejectTitle, rejectBody, rejectData);
        }
    } catch (err) {
        notification = { sent: false, error: err.message };
    }
    if (notification && notification.sent === false) {
        console.warn('[notify] reject notification failed', {
            requestId: requestId,
            clinicId: clinicId,
            reason: notification.reason || 'unknown',
            error: notification.error || null,
        });
    }

    return {
        success: true,
        action: 'reject',
        requestId: requestId,
        notificationSent: notification.sent === true,
        notificationError: notification.error,
        notificationReason: notification.reason,
    };
}

module.exports = async function handler(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method Not Allowed' });

    var token = getBearerToken(req.headers.authorization);
    if (!token) return jsonError(res, 401, 'missing_token', 'Missing Firebase ID token');

    var decoded;
    try {
        decoded = await admin.auth().verifyIdToken(token);
    } catch (err) {
        return jsonError(res, 401, 'invalid_token', 'Invalid Firebase ID token');
    }

    var body = parseBody(req.body);
    var action = body.action;
    var requestId = body.requestId;
    var clinicId = body.clinicId;
    if (!action || !requestId || !clinicId) {
        return jsonError(res, 400, 'missing_fields', 'action, requestId and clinicId are required');
    }
    if (decoded.uid !== clinicId) {
        return jsonError(res, 403, 'clinic_mismatch', 'Token uid does not match clinicId');
    }

    try {
        await assertClinicFeature(db, clinicId, 'appointments_management');
        var payload;
        if (action === 'approve') {
            payload = await approveRequest(requestId, clinicId, decoded.uid);
        } else if (action === 'reject') {
            payload = await rejectRequest(
                requestId,
                clinicId,
                decoded.uid,
                body.rejectionReason || '',
                body.rejectionNotes || ''
            );
        } else {
            return jsonError(res, 400, 'invalid_action', 'action must be approve or reject');
        }
        return res.status(200).json(payload);
    } catch (err) {
        var status = err.httpStatus || 500;
        var code = err.code || 'internal_error';
        console.error('[appointment-action]', code, err.message);
        if (code === 'FEATURE_NOT_ALLOWED') {
            return res.status(status).json({
                success: false,
                ok: false,
                error: code,
                code: code,
                message: err.message,
                requiredPlan: err.requiredPlan || 'basic',
            });
        }
        return jsonError(res, status, code, err.message);
    }
};
