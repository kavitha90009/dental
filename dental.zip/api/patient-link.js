// =============================================================================
// /api/patient-link — patient ↔ clinic record linking (3 actions)
// =============================================================================
//
// One Vercel function, three actions dispatched by `body.action` (POST):
//
//   action = "generate-code"   ← dashboard generates a 6-digit access code
//     auth: Firebase ID token, uid must equal clinicId
//     body: { action, clinicId, patientId, expiresInDays? }
//     returns: { code, expiresAt }    (plain code shown ONCE to clinic staff)
//
//   action = "verify-link"     ← patient app links a Google account to an
//                                 existing unlinked clinic patient record
//     auth: Firebase ID token from the Google-signed-in patient
//     body: { action, clinicId, normalizedPhone, accessCode, displayName? }
//     returns: { patientId, clinicId, linkStatus: "linked" }
//
//   action = "create-or-link"  ← patient app's first-touch: link to existing
//                                 or create a new patient record. NEVER
//                                 auto-links a manual record (must use code).
//     auth: Firebase ID token from the Google-signed-in patient
//     body: { action, clinicId, normalizedPhone, displayName?, phone? }
//     returns: one of
//        { patientId, clinicId, linkStatus: "linked", created: bool }
//        { error: "REQUIRES_ACCESS_CODE",     patientId }
//        { error: "ALREADY_LINKED_TO_OTHER" }
//
// Phone number ALONE never returns sensitive data — these endpoints only
// return the patientId on a successful auth-bound link, never patient fields.
//
// All reads/writes use the Firebase Admin SDK and bypass Firestore rules.
// =============================================================================

var admin  = require('firebase-admin');
var crypto = require('crypto');

if (!admin.apps.length) {
    var privateKey = (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
    admin.initializeApp({
        credential: admin.credential.cert({
            projectId:   process.env.FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey:  privateKey,
        }),
    });
}

var db = admin.firestore();
var FieldValue = admin.firestore.FieldValue;

// ─────────────────────────────────────────────────────────────────────────────
// Constants & helpers
// ─────────────────────────────────────────────────────────────────────────────
var ACCESS_CODE_DEFAULT_TTL_DAYS = 7;
var ACCESS_CODE_MAX_TTL_DAYS     = 30;
// Per-deployment salt. No hardcoded fallback ships in source — set
// ACCESS_CODE_SALT in your environment (see api/.env.example).
var ACCESS_CODE_SALT             = process.env.ACCESS_CODE_SALT || '';

var _utils = require('./_utils');
var getBearerToken = _utils.getBearerToken;
var parseBody      = _utils.parseBody;
var jsonError      = _utils.jsonError;
var normalizePhone = _utils.normalizePhone;

function hashAccessCode(code, clinicId, patientId) {
    // Scoped hash so a code from one patient/clinic can't replay against
    // another even if the same plain digits collide.
    var input = String(code) + ':' + String(clinicId) + ':' + String(patientId) +
                ':' + ACCESS_CODE_SALT;
    return crypto.createHash('sha256').update(input).digest('hex');
}

function generateAccessCode() {
    // Cryptographically secure 6-digit code, leading zeros allowed.
    var n = crypto.randomInt(0, 1000000);
    return String(n).padStart(6, '0');
}

function timestampToMillis(ts) {
    if (!ts) return 0;
    if (typeof ts.toMillis === 'function') return ts.toMillis();
    if (typeof ts === 'number') return ts;
    return 0;
}

async function verifyIdToken(req) {
    var token = getBearerToken(req.headers.authorization);
    if (!token) {
        var err = new Error('Missing Firebase ID token');
        err.httpStatus = 401; err.code = 'MISSING_TOKEN';
        throw err;
    }
    try {
        return await admin.auth().verifyIdToken(token);
    } catch (e) {
        var bad = new Error('Invalid Firebase ID token');
        bad.httpStatus = 401; bad.code = 'INVALID_TOKEN';
        throw bad;
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Action: generate-code  (dashboard → server)
// ─────────────────────────────────────────────────────────────────────────────
async function handleGenerateCode(req, res, body) {
    var decoded = await verifyIdToken(req);

    var clinicId  = body.clinicId  || '';
    var patientId = body.patientId || '';
    if (!clinicId || !patientId) {
        return jsonError(res, 400, 'MISSING_FIELDS',
            'clinicId and patientId are required');
    }
    if (decoded.uid !== clinicId) {
        return jsonError(res, 403, 'CLINIC_MISMATCH',
            'Token uid does not match clinicId');
    }

    var ttlDays = parseInt(body.expiresInDays, 10);
    if (!ttlDays || ttlDays < 1) ttlDays = ACCESS_CODE_DEFAULT_TTL_DAYS;
    if (ttlDays > ACCESS_CODE_MAX_TTL_DAYS) ttlDays = ACCESS_CODE_MAX_TTL_DAYS;

    var patientRef = db.collection('patients').doc(patientId);
    var snap = await patientRef.get();
    if (!snap.exists) {
        return jsonError(res, 404, 'PATIENT_NOT_FOUND',
            'Patient not found');
    }
    var data = snap.data() || {};
    if (data.clinicId !== clinicId) {
        return jsonError(res, 403, 'PATIENT_CLINIC_MISMATCH',
            'Patient does not belong to this clinic');
    }
    if (data.patientUid) {
        return jsonError(res, 409, 'PATIENT_ALREADY_LINKED',
            'Patient is already linked to an account');
    }

    var code = generateAccessCode();
    var hash = hashAccessCode(code, clinicId, patientId);
    var expiresAt = admin.firestore.Timestamp.fromMillis(
        Date.now() + ttlDays * 24 * 60 * 60 * 1000
    );

    await patientRef.set({
        accessCodeHash:      hash,
        accessCodeExpiresAt: expiresAt,
        accessCodeUsedAt:    null,
        updatedAt:           FieldValue.serverTimestamp(),
    }, { merge: true });

    return res.status(200).json({
        success:   true,
        code:      code,
        expiresAt: expiresAt.toMillis(),
        ttlDays:   ttlDays,
    });
}

// ─────────────────────────────────────────────────────────────────────────────
// Internal: find the (single) patient doc for a (clinicId, normalizedPhone)
// Returns the snapshot, or null if not found.
// ─────────────────────────────────────────────────────────────────────────────
async function findPatientByClinicAndPhone(clinicId, normalizedPhone) {
    if (!clinicId || !normalizedPhone) return null;
    var qs = await db.collection('patients')
        .where('clinicId', '==', clinicId)
        .where('normalizedPhone', '==', normalizedPhone)
        .limit(1)
        .get();
    if (qs.empty) return null;
    return qs.docs[0];
}

async function upsertPatientsAppLink(uid, decoded, clinicId, patientId, normalizedPhone) {
    var ref = db.collection('patients_app').doc(uid);
    var snap = await ref.get();
    var existingData = snap.exists ? (snap.data() || {}) : {};
    var now = FieldValue.serverTimestamp();
    var linkedEntry = {
        patientId:        patientId,
        normalizedPhone:  normalizedPhone,
        linkedAt:         admin.firestore.Timestamp.now(),
    };

    // 1. Top-level profile fields — safe to write with set(merge:true).
    var base = {
        displayName: decoded.name  || existingData.displayName || '',
        email:       decoded.email || existingData.email       || '',
        photoUrl:    decoded.picture || existingData.photoUrl  || null,
        provider:    'google',
        updatedAt:   now,
    };
    if (!snap.exists) base.createdAt = now;
    await ref.set(base, { merge: true });

    // 2. Nested linkedClinics map — MUST use update() with dot-notation,
    //    not set(merge:true). Firestore traverses dot-paths only inside
    //    update(); inside set(merge) the key is stored as a literal
    //    field name with a dot in it. The older version of this function
    //    used set(merge), which left every linked user with rows like
    //    `linkedClinics.<clinicId>` as top-level fields and an EMPTY
    //    `linkedClinics` map — so the patient app's loadProfile read
    //    null and asked the user to re-link.
    //
    //    On the same write we also migrate any legacy literal-dot keys
    //    that this user might still have from the broken era: copy them
    //    into the proper nested map (without clobbering current writes)
    //    and delete the legacy literal field. Idempotent — running
    //    against an already-migrated doc is a no-op.
    var updates = {};
    updates['linkedClinics.' + clinicId] = linkedEntry;

    Object.keys(existingData).forEach(function(k) {
        if (k.indexOf('linkedClinics.') !== 0) return;
        var legacyClinicId = k.substring('linkedClinics.'.length);
        if (!legacyClinicId) return;
        // Always drop the legacy literal field.
        updates[k] = FieldValue.delete();
        // Preserve it inside the nested map UNLESS it's the clinicId we
        // just wrote this turn (avoid overwriting fresh data with stale).
        if (legacyClinicId !== clinicId) {
            updates['linkedClinics.' + legacyClinicId] = existingData[k];
        }
    });
    await ref.update(updates);
}

// ─────────────────────────────────────────────────────────────────────────────
// Action: verify-link  (patient app → server, with access code)
// ─────────────────────────────────────────────────────────────────────────────
async function handleVerifyLink(req, res, body) {
    var decoded = await verifyIdToken(req);

    var clinicId        = body.clinicId || '';
    var normalizedPhone = normalizePhone(body.normalizedPhone || body.phone || '');
    var accessCode      = String(body.accessCode || '').trim();

    if (!clinicId || !normalizedPhone || !accessCode) {
        return jsonError(res, 400, 'MISSING_FIELDS',
            'clinicId, normalizedPhone, accessCode are required');
    }

    // Find the patient by clinicId + normalizedPhone (server-side, rules bypass).
    var doc = await findPatientByClinicAndPhone(clinicId, normalizedPhone);
    if (!doc) {
        return jsonError(res, 404, 'PATIENT_NOT_FOUND',
            'No patient with this phone in this clinic');
    }
    var data = doc.data() || {};

    // Already linked to THIS uid? Idempotent success.
    if (data.patientUid && data.patientUid === decoded.uid) {
        await upsertPatientsAppLink(decoded.uid, decoded, clinicId, doc.id, normalizedPhone);
        return res.status(200).json({
            success: true, patientId: doc.id, clinicId: clinicId,
            linkStatus: 'linked', alreadyLinked: true,
        });
    }
    // Linked to a DIFFERENT uid? Block.
    if (data.patientUid && data.patientUid !== decoded.uid) {
        return jsonError(res, 409, 'ALREADY_LINKED_TO_OTHER',
            'This phone is already linked to another account');
    }
    // Unlinked — require valid, unexpired access code.
    if (!data.accessCodeHash) {
        return jsonError(res, 400, 'NO_ACCESS_CODE',
            'No active access code for this patient');
    }
    var expiresAtMs = timestampToMillis(data.accessCodeExpiresAt);
    if (expiresAtMs && expiresAtMs < Date.now()) {
        return jsonError(res, 400, 'ACCESS_CODE_EXPIRED',
            'Access code has expired');
    }
    if (data.accessCodeUsedAt) {
        return jsonError(res, 400, 'ACCESS_CODE_USED',
            'Access code has already been used');
    }

    var supplied = hashAccessCode(accessCode, clinicId, doc.id);
    // Constant-time compare to defeat timing oracles.
    var a = Buffer.from(supplied, 'hex');
    var b = Buffer.from(String(data.accessCodeHash), 'hex');
    var match = a.length === b.length && crypto.timingSafeEqual(a, b);
    if (!match) {
        return jsonError(res, 400, 'INVALID_ACCESS_CODE',
            'Access code is incorrect');
    }

    // Link.
    var nowTs = admin.firestore.Timestamp.now();
    var nextSource = (data.source === 'manual') ? 'manual_linked' : (data.source || 'manual_linked');
    await doc.ref.set({
        patientUid:          decoded.uid,
        linkStatus:          'linked',
        source:              nextSource,
        linkedAt:            nowTs,
        linkedBy:            'access_code',
        accessCodeHash:      null,
        accessCodeExpiresAt: null,
        accessCodeUsedAt:    nowTs,
        updatedAt:           FieldValue.serverTimestamp(),
    }, { merge: true });

    await upsertPatientsAppLink(decoded.uid, decoded, clinicId, doc.id, normalizedPhone);

    return res.status(200).json({
        success: true, patientId: doc.id, clinicId: clinicId, linkStatus: 'linked',
    });
}

// ─────────────────────────────────────────────────────────────────────────────
// Action: create-or-link  (patient app → server, first touch)
// ─────────────────────────────────────────────────────────────────────────────
async function handleCreateOrLink(req, res, body) {
    var decoded = await verifyIdToken(req);

    var clinicId        = body.clinicId || '';
    var rawPhone        = body.phone || body.normalizedPhone || '';
    var normalizedPhone = normalizePhone(rawPhone);
    // Trust the decoded Google identity over anything the client sent —
    // decoded.name / decoded.email are signed by Google + verified by
    // Firebase Admin, so they're the right primary source for the patient's
    // display name and contact email. Fall back to body.displayName for
    // older clients and finally an empty string.
    var displayName = (decoded.name || body.displayName || '').toString().trim();
    var displayEmail = (decoded.email || body.email || '').toString().trim();

    if (!clinicId || !normalizedPhone) {
        return jsonError(res, 400, 'MISSING_FIELDS',
            'clinicId and phone are required');
    }

    // Validate the clinic exists (so we can't write patients into ghost clinics).
    var clinicSnap = await db.collection('clinics').doc(clinicId).get();
    if (!clinicSnap.exists) {
        return jsonError(res, 404, 'CLINIC_NOT_FOUND',
            'Clinic not found');
    }

    var doc = await findPatientByClinicAndPhone(clinicId, normalizedPhone);

    // Case 1: existing patient already linked to THIS uid.
    if (doc && doc.data().patientUid === decoded.uid) {
        await upsertPatientsAppLink(decoded.uid, decoded, clinicId, doc.id, normalizedPhone);
        return res.status(200).json({
            success: true, patientId: doc.id, clinicId: clinicId,
            linkStatus: 'linked', alreadyLinked: true, created: false,
        });
    }

    // Case 2: existing patient linked to a DIFFERENT uid → block.
    if (doc && doc.data().patientUid && doc.data().patientUid !== decoded.uid) {
        return jsonError(res, 409, 'ALREADY_LINKED_TO_OTHER',
            'This phone is already linked to another account');
    }

    // Case 3: existing patient is UNLINKED → never auto-link, force access code.
    if (doc) {
        return res.status(403).json({
            success:    false,
            error:      'REQUIRES_ACCESS_CODE',
            code:       'REQUIRES_ACCESS_CODE',
            patientId:  doc.id,
            clinicId:   clinicId,
            message:    'A patient record exists for this phone. Enter the clinic access code to link your account.',
        });
    }

    // Case 4: no existing patient → create a new app-originated record.
    // Use the Google-issued displayName (verified via the ID token) as
    // the patient name, and store the Google email when present so the
    // dashboard's patient row is usable on day one — the patient still
    // gets a "complete your profile" nudge in-app when the name fell
    // back to "مريض جديد".
    var phoneRaw = String(rawPhone).trim();
    var nowTs = admin.firestore.Timestamp.now();
    var newRef = db.collection('patients').doc();
    var newPatientDoc = {
        clinicId:        clinicId,
        name:            displayName || 'New patient',
        phone:           phoneRaw || normalizedPhone,
        normalizedPhone: normalizedPhone,
        patientUid:      decoded.uid,
        source:          'app',
        linkStatus:      'linked',
        linkedAt:        nowTs,
        linkedBy:        'app_signup',
        accessCodeHash:  null,
        accessCodeExpiresAt: null,
        accessCodeUsedAt:    null,
        createdAt:       FieldValue.serverTimestamp(),
        updatedAt:       FieldValue.serverTimestamp(),
    };
    if (displayEmail) newPatientDoc.email = displayEmail;
    await newRef.set(newPatientDoc);

    await upsertPatientsAppLink(decoded.uid, decoded, clinicId, newRef.id, normalizedPhone);

    return res.status(200).json({
        success: true, patientId: newRef.id, clinicId: clinicId,
        linkStatus: 'linked', created: true,
    });
}

// ─────────────────────────────────────────────────────────────────────────────
// WhatsApp invite link  ── single-use, 24h, server-stored as hash only
// ─────────────────────────────────────────────────────────────────────────────
var INVITE_TTL_HOURS         = 24;
// Use the www host so the deep link hits a Play Console-verified domain.
// apex (your-domain.com) currently fails App Links verification because its
// /.well-known/assetlinks.json 307-redirects to www, and Android does not
// follow redirects during assetlinks verification — verification only
// succeeds against the canonical www host. Switching the generated link
// to www avoids the disambiguation chooser on Android 12+ entirely.
//
// DO NOT switch back to apex without first serving assetlinks.json directly
// (no redirect) from BOTH hosts and re-running the deep-link verification.
var INVITE_PUBLIC_BASE       = 'https://www.your-domain.com/patient/link';
var INVITE_DEBUG_FALLBACK    = 'dentalapp://patient/link';
// Per-deployment salt. No hardcoded fallback ships in source — set
// INVITE_TOKEN_SALT in your environment (see api/.env.example).
var INVITE_TOKEN_SALT        = process.env.INVITE_TOKEN_SALT || '';

function generateInviteToken() {
    // 32 random bytes → 64-char hex. Cryptographically strong.
    return crypto.randomBytes(32).toString('hex');
}

function hashInviteToken(token) {
    return crypto.createHash('sha256')
                 .update(String(token) + ':' + INVITE_TOKEN_SALT)
                 .digest('hex');
}

// Build the WhatsApp deep link for a normalized (digits-only, country-code-
// prefixed) phone, with an English message containing the invite URL.
function buildWhatsappUrl(normalizedPhone, patientName, inviteUrl) {
    var msg =
        'Hello ' + (patientName || '') + ',\n' +
        'To link your account with the clinic app, open this secure link and sign in with Google:\n\n' +
        inviteUrl + '\n\n' +
        'Do not share this link with anyone. It is valid for 24 hours and can be used only once.';
    return 'https://wa.me/' + normalizedPhone + '?text=' + encodeURIComponent(msg);
}

async function handleGenerateWhatsappLink(req, res, body) {
    var decoded = await verifyIdToken(req);

    var clinicId  = body.clinicId  || '';
    var patientId = body.patientId || '';
    if (!clinicId || !patientId) {
        return jsonError(res, 400, 'MISSING_FIELDS', 'clinicId and patientId are required');
    }
    if (decoded.uid !== clinicId) {
        return jsonError(res, 403, 'CLINIC_MISMATCH', 'Token uid does not match clinicId');
    }

    var patientRef = db.collection('patients').doc(patientId);
    var patientSnap = await patientRef.get();
    if (!patientSnap.exists) {
        return jsonError(res, 404, 'PATIENT_NOT_FOUND', 'Patient not found');
    }
    var patient = patientSnap.data() || {};
    if (patient.clinicId !== clinicId) {
        return jsonError(res, 403, 'PATIENT_CLINIC_MISMATCH',
            'Patient does not belong to this clinic');
    }
    if (patient.patientUid) {
        return jsonError(res, 409, 'PATIENT_ALREADY_LINKED',
            'Patient is already linked to an app account');
    }

    // Build the phone for WhatsApp BEFORE creating the invite — if the
    // number can't be sensibly normalized we still create the invite, but
    // we return a warning so the dashboard offers a manual-copy fallback.
    var normalizedPhone = normalizePhone(patient.normalizedPhone || patient.phone || '');
    var phoneWarning = null;
    if (!normalizedPhone || (!normalizedPhone.startsWith('966') &&
                              !normalizedPhone.startsWith('20')  &&
                              normalizedPhone.length < 10)) {
        phoneWarning = 'Could not detect the country code for this number — open the link manually.';
    }

    // Invalidate prior unused invites for this (clinicId, patientId).
    // Query by patientId only (auto single-field index) and filter the
    // remaining fields client-side — keeps us off composite-index land.
    var priorSnap = await db.collection('patient_link_invites')
        .where('patientId', '==', patientId)
        .get();
    var toRevoke = priorSnap.docs.filter(function(d) {
        var v = d.data() || {};
        return v.clinicId === clinicId && !v.usedAt && !v.revokedAt;
    });
    if (toRevoke.length) {
        var batch = db.batch();
        toRevoke.forEach(function(d) {
            batch.update(d.ref, {
                revokedAt:    FieldValue.serverTimestamp(),
                revokeReason: 'superseded',
            });
        });
        await batch.commit();
    }

    // Mint the invite.
    var token     = generateInviteToken();
    var tokenHash = hashInviteToken(token);
    var expiresAt = admin.firestore.Timestamp.fromMillis(
        Date.now() + INVITE_TTL_HOURS * 60 * 60 * 1000
    );

    var inviteRef = await db.collection('patient_link_invites').add({
        clinicId:        clinicId,
        patientId:       patientId,
        normalizedPhone: normalizedPhone,
        patientName:     patient.name || '',
        tokenHash:       tokenHash,
        createdAt:       FieldValue.serverTimestamp(),
        expiresAt:       expiresAt,
        usedAt:          null,
        revokedAt:       null,
        createdBy:       clinicId,
        channel:         'whatsapp',
        linkedUid:       null,
        linkedEmail:     null,
    });

    var inviteUrl   = INVITE_PUBLIC_BASE + '?t=' + token;
    var whatsappUrl = normalizedPhone
        ? buildWhatsappUrl(normalizedPhone, patient.name, inviteUrl)
        : null;

    return res.status(200).json({
        ok:             true,
        inviteId:       inviteRef.id,
        inviteUrl:      inviteUrl,
        whatsappUrl:    whatsappUrl,
        expiresAt:      expiresAt.toMillis(),
        expiresInHours: INVITE_TTL_HOURS,
        debugDeepLink:  INVITE_DEBUG_FALLBACK + '?t=' + token,
        phoneWarning:   phoneWarning,
    });
}

async function handleVerifyInviteLink(req, res, body) {
    var decoded = await verifyIdToken(req);
    var token   = String(body.token || '').trim();
    if (!token) {
        return jsonError(res, 400, 'MISSING_TOKEN', 'token is required');
    }
    var hash = hashInviteToken(token);

    var inviteSnap = await db.collection('patient_link_invites')
        .where('tokenHash', '==', hash)
        .limit(1)
        .get();
    if (inviteSnap.empty) {
        return jsonError(res, 404, 'INVITE_INVALID',
            'This link is invalid. Please request a new one from the clinic.');
    }
    var inviteRef  = inviteSnap.docs[0].ref;
    var invite     = inviteSnap.docs[0].data() || {};

    if (invite.usedAt) {
        return jsonError(res, 410, 'INVITE_USED',
            'This link has already been used. Please request a new one from the clinic.');
    }
    if (invite.revokedAt) {
        return jsonError(res, 410, 'INVITE_REVOKED',
            'This link has been revoked. Please request a new one from the clinic.');
    }
    var expiresAtMs = timestampToMillis(invite.expiresAt);
    if (expiresAtMs && expiresAtMs < Date.now()) {
        return jsonError(res, 410, 'INVITE_EXPIRED',
            'This link has expired. Please request a new one from the clinic.');
    }

    var patientRef  = db.collection('patients').doc(invite.patientId);
    var patientSnap = await patientRef.get();
    if (!patientSnap.exists) {
        return jsonError(res, 404, 'PATIENT_NOT_FOUND',
            'No patient profile was found for this link.');
    }
    var patient = patientSnap.data() || {};
    if (patient.clinicId !== invite.clinicId) {
        return jsonError(res, 403, 'CLINIC_MISMATCH',
            'The link details do not match.');
    }

    // Already linked to a different uid → block. Same uid → idempotent.
    if (patient.patientUid && patient.patientUid !== decoded.uid) {
        return jsonError(res, 409, 'ALREADY_LINKED_TO_OTHER',
            'This profile is linked to another account. Please contact the clinic.');
    }

    // Transaction: mark invite used + mark patient linked.
    var nowTs = admin.firestore.Timestamp.now();
    await db.runTransaction(async function(tx) {
        var freshInvite = await tx.get(inviteRef);
        var fi = freshInvite.data() || {};
        if (fi.usedAt) {
            var err = new Error('INVITE_USED');
            err.httpStatus = 410; err.code = 'INVITE_USED';
            throw err;
        }
        var freshPatient = await tx.get(patientRef);
        var fp = freshPatient.data() || {};
        if (fp.patientUid && fp.patientUid !== decoded.uid) {
            var err2 = new Error('ALREADY_LINKED_TO_OTHER');
            err2.httpStatus = 409; err2.code = 'ALREADY_LINKED_TO_OTHER';
            throw err2;
        }
        var nextSource = (fp.source === 'manual') ? 'manual_linked'
            : (fp.source || 'manual_linked');
        tx.update(patientRef, {
            patientUid:           decoded.uid,
            linkStatus:           'linked',
            source:               nextSource,
            linkedAt:             nowTs,
            linkedBy:             'whatsapp_invite',
            linkedEmail:          decoded.email || null,
            accessCodeHash:       null,
            accessCodeExpiresAt:  null,
            accessCodeUsedAt:     null,
            updatedAt:            FieldValue.serverTimestamp(),
        });
        tx.update(inviteRef, {
            usedAt:      nowTs,
            linkedUid:   decoded.uid,
            linkedEmail: decoded.email || null,
        });
    });

    await upsertPatientsAppLink(
        decoded.uid, decoded, invite.clinicId, invite.patientId,
        invite.normalizedPhone || ''
    );

    return res.status(200).json({
        ok:        true,
        linked:    true,
        clinicId:  invite.clinicId,
        patientId: invite.patientId,
    });
}

// ─────────────────────────────────────────────────────────────────────────────
// Action: update-profile  (patient app → server)
// ─────────────────────────────────────────────────────────────────────────────
//
// Why this exists: `patients/{patientId}` is clinic-owned. Firestore
// rules (patient-app/firestore.rules:149-151) allow updates only when
// auth.uid == resource.data.clinicId — i.e. the clinic admin, NOT the
// linked patient. The patient app needs a way to let a linked patient
// edit their own display name (and contact email) so the dashboard's
// patient list shows the human-edited name without the clinic having
// to retype it. We do that here via Admin SDK, scoped tightly:
//
//   1. Token is a Firebase Auth ID token (Google sign-in).
//   2. patientId must exist.
//   3. patient.clinicId must equal the body.clinicId we were called
//      with (defence against cross-clinic patientId reuse).
//   4. patient.patientUid must equal the decoded uid — i.e. the
//      caller IS the linked patient on this record. No other user
//      can edit this profile via this endpoint.
//
// Writes ONLY `name`, `email` (when provided), `updatedAt`. Phone,
// normalizedPhone, patientUid, clinicId, linkStatus, accessCode*,
// notes, and any clinic-owned medical field are intentionally never
// touched here — they're the clinic's surface or the system's.
async function handleUpdateProfile(req, res, body) {
    var decoded = await verifyIdToken(req);

    var clinicId  = body.clinicId  || '';
    var patientId = body.patientId || '';
    var newName   = (body.newName || '').toString().trim();
    var newEmail  = (body.newEmail || '').toString().trim();

    if (!clinicId || !patientId) {
        return jsonError(res, 400, 'MISSING_FIELDS',
            'clinicId and patientId are required');
    }
    if (newName.length < 2) {
        return jsonError(res, 400, 'NAME_TOO_SHORT',
            'newName must be at least 2 characters');
    }

    var patientRef = db.collection('patients').doc(patientId);
    var snap = await patientRef.get();
    if (!snap.exists) {
        return jsonError(res, 404, 'PATIENT_NOT_FOUND', 'Patient not found');
    }
    var data = snap.data() || {};
    if (data.clinicId !== clinicId) {
        return jsonError(res, 403, 'PATIENT_CLINIC_MISMATCH',
            'Patient does not belong to this clinic');
    }
    if (!data.patientUid || data.patientUid !== decoded.uid) {
        return jsonError(res, 403, 'NOT_PROFILE_OWNER',
            'You can only update your own linked profile');
    }

    var patUpdate = {
        name:       newName,
        updatedAt:  FieldValue.serverTimestamp(),
    };
    if (newEmail) patUpdate.email = newEmail;
    await patientRef.update(patUpdate);

    var appRef = db.collection('patients_app').doc(decoded.uid);
    var appUpdate = {
        displayName: newName,
        updatedAt:   FieldValue.serverTimestamp(),
    };
    if (newEmail) appUpdate.email = newEmail;
    await appRef.set(appUpdate, { merge: true });

    return res.status(200).json({
        success:   true,
        ok:        true,
        patientId: patientId,
        clinicId:  clinicId,
        name:      newName,
        email:     newEmail || null,
    });
}

// ─────────────────────────────────────────────────────────────────────────────
// Top-level dispatch
// ─────────────────────────────────────────────────────────────────────────────
module.exports = async function handler(req, res) {
    if (req.method !== 'POST') {
        return res.status(405).json({ error: 'Method Not Allowed' });
    }
    var body = parseBody(req.body);
    var action = String(body.action || '').trim();
    try {
        if (action === 'generate-code')          return await handleGenerateCode(req, res, body);
        if (action === 'verify-link')            return await handleVerifyLink(req, res, body);
        if (action === 'create-or-link')         return await handleCreateOrLink(req, res, body);
        if (action === 'generate-whatsapp-link') return await handleGenerateWhatsappLink(req, res, body);
        if (action === 'verify-invite-link')     return await handleVerifyInviteLink(req, res, body);
        if (action === 'update-profile')         return await handleUpdateProfile(req, res, body);
        return jsonError(res, 400, 'INVALID_ACTION',
            'action must be one of generate-code | verify-link | create-or-link | generate-whatsapp-link | verify-invite-link | update-profile');
    } catch (err) {
        var status = err.httpStatus || 500;
        var code   = err.code       || 'INTERNAL_ERROR';
        console.error('[patient-link]', action || '(no action)', code, err.message);
        return jsonError(res, status, code, err.message);
    }
};
