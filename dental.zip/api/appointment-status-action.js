// Secure appointment operational actions for clinic dashboard.
// Auth: Firebase ID token in Authorization: Bearer <token>.

var admin = require('firebase-admin');

if (!admin.apps.length) {
    var privateKey = (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
    admin.initializeApp({
        credential: admin.credential.cert({
            projectId:   process.env.FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey:  privateKey,
        }),
    });
}

var db = admin.firestore();
var FieldValue = admin.firestore.FieldValue;
var assertClinicFeature = require('./_features').assertClinicFeature;

function cleanUndefined(obj) {
    return Object.fromEntries(Object.entries(obj).filter(function(entry) {
        return entry[1] !== undefined;
    }));
}

var _utils = require('./_utils');
var getBearerToken = _utils.getBearerToken;
var parseBody      = _utils.parseBody;
var jsonError      = _utils.jsonError;
var normalizePhone = _utils.normalizePhone;
var stringData     = _utils.stringData;

async function getAppointment(appointmentId, clinicId) {
    if (!appointmentId || !clinicId) {
        var missing = new Error('appointmentId and clinicId are required');
        missing.httpStatus = 400;
        missing.code = 'missing_fields';
        throw missing;
    }
    var ref = db.collection('appointments').doc(appointmentId);
    var snap = await ref.get();
    if (!snap.exists) {
        var notFound = new Error('appointment not found');
        notFound.httpStatus = 404;
        notFound.code = 'appointment_not_found';
        throw notFound;
    }
    var appt = snap.data() || {};
    if (appt.clinicId !== clinicId) {
        var wrongClinic = new Error('wrong clinic');
        wrongClinic.httpStatus = 403;
        wrongClinic.code = 'wrong_clinic';
        throw wrongClinic;
    }
    return { ref: ref, data: appt };
}

// Canonical digits-only form. Must match patient app + appointment-action.js
// + complete-session.js + reminders.js so a guest's FCM token is always
// looked up at the same Firestore key.
// normalizePhone is imported from ./_utils above.

async function enqueuePendingGuestNotification(normalizedKey, title, body, data, reason) {
    try {
        await db.collection('pending_guest_notifications').add({
            normalizedPhone: normalizedKey,
            title: String(title || ''),
            body:  String(body  || ''),
            data:  stringData(data || {}),
            attempts: 0,
            reason: reason || '',
            createdAt: FieldValue.serverTimestamp(),
            lastTriedAt: null,
        });
    } catch (err) {
        console.warn('[pending-guest-notif] failed to enqueue:', err && err.message);
    }
}

// Terminal states an appointment can be in. Once a doc reaches any of
// these the dashboard hides its action buttons (dashboard/index.html
// isTerminalAppt mirrors this list — keep them in sync) AND the
// mutation handlers below (cancel / reschedule / no_show) reject so
// a stale client or a direct API call can't resurrect or re-finalise
// a settled appointment.
var TERMINAL_STATUSES = ['completed', 'done', 'cancelled', 'canceled',
                          'rejected', 'no_show', 'deleted'];

function assertNotTerminal(appt) {
    if (!appt) return;
    if (appt.deleted === true || appt.isDeleted === true) {
        var del = new Error('APPOINTMENT_TERMINAL');
        del.httpStatus = 409; del.code = 'APPOINTMENT_TERMINAL';
        del.message = 'This appointment is in a final state and no action can be taken on it.';
        throw del;
    }
    if (TERMINAL_STATUSES.indexOf(appt.status) >= 0) {
        var msg;
        if (appt.status === 'completed' || appt.status === 'done') {
            msg = 'A completed appointment cannot be modified.';
        } else if (appt.status === 'cancelled' || appt.status === 'canceled') {
            msg = 'A cancelled appointment cannot be modified.';
        } else {
            msg = 'This appointment is in a final state and no action can be taken on it.';
        }
        var err = new Error('APPOINTMENT_TERMINAL');
        err.httpStatus = 409; err.code = 'APPOINTMENT_TERMINAL';
        err.message = msg;
        throw err;
    }
}

// Attempts FCM delivery to (in order): app user via patientUid → guest
// via appointment's patientPhone → patient's manual record phone.
// Falls back to pending_guest_notifications queue if no token resolves.
async function notifyPatientWithFallback(appt, title, body, data) {
    var patientUid = appt && appt.patientUid;
    var apptPhone  = appt && (appt.patientPhone || appt.phone || '');

    if (patientUid) {
        try {
            var snap = await db.collection('patients_app').doc(patientUid).get();
            if (snap.exists) {
                var t = snap.data().fcmToken;
                if (t) {
                    await admin.messaging().send({
                        token: t,
                        notification: { title: title, body: body },
                        data: stringData(data),
                        android: {
                            priority: 'high',
                            notification: { channelId: 'appointments', sound: 'default', priority: 'high' },
                        },
                    });
                    return { sent: true, audience: 'app_user' };
                }
            }
        } catch (err) {
            console.warn('[notify] app_user send failed:', err && err.message);
        }
    }

    var phoneKey = normalizePhone(apptPhone);
    if (phoneKey) {
        try {
            var gsnap = await db.collection('guest_fcm_tokens').doc(phoneKey).get();
            if (gsnap.exists) {
                var gt = gsnap.data().fcmToken;
                if (gt) {
                    await admin.messaging().send({
                        token: gt,
                        notification: { title: title, body: body },
                        data: stringData(data),
                        android: {
                            priority: 'high',
                            notification: { channelId: 'appointments', sound: 'default', priority: 'high' },
                        },
                    });
                    return { sent: true, audience: 'guest', normalizedPhone: phoneKey };
                }
            }
            await enqueuePendingGuestNotification(phoneKey, title, body, data, 'no_guest_token');
            return { sent: false, reason: 'NO_FCM_TOKEN', queued: true };
        } catch (err) {
            console.warn('[notify] guest send failed:', err && err.message);
            return { sent: false, reason: 'send_error', error: err && err.message };
        }
    }

    return { sent: false, reason: 'NO_PATIENT_IDENTITY' };
}

async function sendPatientNotification(patientUid, title, body, data) {
    // Legacy wrapper retained for backwards compat — most call sites use
    // notifyPatientWithFallback directly now. Kept thin so we don't change
    // call signatures across the file unnecessarily.
    if (!patientUid) return { sent: false, reason: 'missing_patient_uid' };
    var snap = await db.collection('patients_app').doc(patientUid).get();
    if (!snap.exists) return { sent: false, reason: 'patient_not_found' };
    var token = snap.data().fcmToken;
    if (!token) return { sent: false, reason: 'no_token' };

    await admin.messaging().send({
        token: token,
        notification: { title: title, body: body },
        data: stringData(data),
        android: {
            priority: 'high',
            notification: {
                channelId: 'appointments',
                sound: 'default',
                priority: 'high',
            },
        },
    });
    return { sent: true };
}

async function sendReminder(appointmentId, clinicId, actorUid) {
    var loaded = await getAppointment(appointmentId, clinicId);
    var appt = loaded.data;
    if (appt.status !== 'scheduled' && appt.status !== 'checked_in') {
        var badStatus = new Error('appointment is not active');
        badStatus.httpStatus = 400;
        badStatus.code = 'invalid_status';
        throw badStatus;
    }

    var notification = await sendPatientNotification(
        appt.patientUid,
        'Appointment reminder',
        'You have an appointment at the clinic now. Please confirm attendance or contact the clinic.',
        {
            type: 'appointment_reminder_now',
            appointmentId: appointmentId,
            clinicId: clinicId,
        }
    ).catch(function(err) {
        return { sent: false, error: err.message };
    });
    if (notification && notification.sent === false) {
        console.warn('[notify] manual reminder notification failed', {
            appointmentId: appointmentId,
            clinicId: clinicId,
            reason: notification.reason || 'unknown',
            error: notification.error || null,
        });
    }

    await loaded.ref.update({
        lastReminderSentAt: FieldValue.serverTimestamp(),
        lastReminderSentBy: actorUid,
        reminderCount: FieldValue.increment(1),
    });

    return { notification: notification };
}

async function rescheduleAppointment(appointmentId, clinicId, actorUid, newDate, newTime, reason) {
    if (!newDate || !newTime) {
        var missing = new Error('newDate and newTime are required');
        missing.httpStatus = 400;
        missing.code = 'missing_reschedule_time';
        throw missing;
    }
    var loaded = await getAppointment(appointmentId, clinicId);
    var appt = loaded.data;
    assertNotTerminal(appt);
    await loaded.ref.update(cleanUndefined({
        status: 'scheduled',
        date: newDate,
        time: newTime,
        rescheduledAt: FieldValue.serverTimestamp(),
        rescheduledBy: actorUid,
        rescheduledFromDate: appt.date,
        rescheduledFromTime: appt.time,
        rescheduleReason: reason || '',
    }));

    // Use guest-aware fallback so guest patients also get reschedule pushes.
    var notification = await notifyPatientWithFallback(
        appt,
        'Your appointment was rescheduled',
        'Your appointment has been changed to ' + newDate + ' at ' + newTime + '.',
        {
            type: 'appointment_rescheduled',
            appointmentId: appointmentId,
            clinicId: clinicId,
            date: newDate,
            time: newTime,
        }
    ).catch(function(err) {
        return { sent: false, error: err.message };
    });
    if (notification && notification.sent === false) {
        console.warn('[notify] reschedule notification failed', {
            appointmentId: appointmentId,
            clinicId: clinicId,
            reason: notification.reason || 'unknown',
            queued: notification.queued === true,
            error: notification.error || null,
        });
    }

    return { notification: notification };
}

async function cancelAppointment(appointmentId, clinicId, actorUid, reason) {
    var loaded = await getAppointment(appointmentId, clinicId);
    var appt = loaded.data;
    assertNotTerminal(appt);
    await loaded.ref.update(cleanUndefined({
        status: 'cancelled',
        cancelledAt: FieldValue.serverTimestamp(),
        cancelledBy: actorUid,
        cancelReason: reason || '',
    }));

    var body = reason
        ? 'Your appointment was cancelled by the clinic. Reason: ' + reason
        : 'Your appointment was cancelled by the clinic. You can book a new appointment in the app.';
    var notification = await notifyPatientWithFallback(
        appt,
        'Appointment cancelled',
        body,
        {
            type: 'appointment_cancelled',
            appointmentId: appointmentId,
            clinicId: clinicId,
            reason: reason || '',
        }
    ).catch(function(err) {
        return { sent: false, error: err.message };
    });
    if (notification && notification.sent === false) {
        console.warn('[notify] clinic-cancel notification failed', {
            appointmentId: appointmentId,
            clinicId: clinicId,
            reason: notification.reason || 'unknown',
            queued: notification.queued === true,
            error: notification.error || null,
        });
    }

    return { notification: notification };
}

async function markNoShow(appointmentId, clinicId, actorUid) {
    var loaded = await getAppointment(appointmentId, clinicId);
    assertNotTerminal(loaded.data);
    await loaded.ref.update({
        status: 'no_show',
        noShowAt: FieldValue.serverTimestamp(),
        noShowBy: actorUid,
    });
    return { notification: { sent: false, reason: 'no_show_notification_disabled' } };
}

// Best-effort clinic-name lookup for notification bodies. The dashboard
// could include the name in the request, but server-resolving it
// guarantees we never leak a stale UI cache into the notification.
async function getClinicName(clinicId) {
    try {
        var snap = await db.collection('clinics').doc(clinicId).get();
        if (!snap.exists) return '';
        var x = snap.data() || {};
        return (x.name || x.clinicName || '').toString().trim();
    } catch (_) {
        return '';
    }
}

function _composeApptBody(intro, clinicName, date, time) {
    var parts = [intro];
    if (clinicName) parts.push('at ' + clinicName);
    if (date) parts.push('on ' + date);
    if (time) parts.push('at ' + time);
    return parts.join(' ') + '.';
}

// New action: dashboard just created an appointment doc directly (the
// staff entered a walk-in or a manual booking, no patient-app request
// flow involved). Read it back from Firestore so we always notify based
// on the real persisted state, then fan out via notifyPatientWithFallback.
async function notifyAppointmentCreated(appointmentId, clinicId) {
    var loaded = await getAppointment(appointmentId, clinicId);
    var appt = loaded.data;
    // Defensive: dashboard may have written the appointment before the
    // linked-patient identity made it onto the doc (stale dropdown
    // cache, walk-in promotion, etc). When patientUid is missing but
    // we have patientId, look up the canonical patientUid/phone from
    // patients/{patientId} so the notifyPatientWithFallback chain can
    // still resolve an FCM target.
    if (!appt.patientUid && appt.patientId) {
        try {
            var patSnap = await db.collection('patients').doc(appt.patientId).get();
            if (patSnap.exists) {
                var pd = patSnap.data() || {};
                if (!appt.patientUid && pd.patientUid) appt.patientUid = pd.patientUid;
                if (!appt.patientPhone && pd.phone) appt.patientPhone = pd.phone;
                if (!appt.phone && pd.phone) appt.phone = pd.phone;
                if (!appt.normalizedPhone && pd.normalizedPhone) appt.normalizedPhone = pd.normalizedPhone;
            }
        } catch (err) {
            console.warn('[notify_created] patient lookup failed:', err && err.message);
        }
    }
    var clinicName = await getClinicName(clinicId);
    var body = _composeApptBody(
        'A new appointment has been booked for you',
        clinicName,
        appt.date || '',
        appt.time || ''
    );
    var notification = await notifyPatientWithFallback(
        appt,
        'New appointment',
        body,
        {
            type: 'appointment_created',
            appointmentId: appointmentId,
            clinicId: clinicId,
        }
    ).catch(function(err) {
        return { sent: false, error: err.message };
    });
    if (notification && notification.sent === false) {
        console.warn('[notify] appointment_created notification failed', {
            appointmentId: appointmentId,
            clinicId: clinicId,
            reason: notification.reason || 'unknown',
            queued: notification.queued === true,
            error: notification.error || null,
        });
    }
    return { notification: notification };
}

// New action: dashboard is about to (or just did) hard-delete the
// appointment doc. We can't read the appointment from Firestore, so
// the caller passes the necessary fields inline. Same notify-pattern
// as cancelAppointment.
async function notifyAppointmentDeleted(clinicId, body) {
    var apptLike = {
        patientUid:   body.patientUid || '',
        patientPhone: body.patientPhone || body.phone || '',
        phone:        body.phone || body.patientPhone || '',
        clinicId:     clinicId,
    };
    var clinicName = await getClinicName(clinicId);
    var notificationBody = _composeApptBody(
        'Appointment cancelled',
        clinicName,
        body.date || '',
        body.time || ''
    );
    var notification = await notifyPatientWithFallback(
        apptLike,
        'Appointment cancelled',
        notificationBody,
        {
            type: 'appointment_cancelled',
            appointmentId: body.appointmentId || '',
            clinicId: clinicId,
        }
    ).catch(function(err) {
        return { sent: false, error: err.message };
    });
    if (notification && notification.sent === false) {
        console.warn('[notify] appointment_deleted notification failed', {
            appointmentId: body.appointmentId || '',
            clinicId: clinicId,
            reason: notification.reason || 'unknown',
            queued: notification.queued === true,
            error: notification.error || null,
        });
    }
    return { notification: notification };
}

module.exports = async function handler(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method Not Allowed' });

    var token = getBearerToken(req.headers.authorization);
    if (!token) return jsonError(res, 401, 'missing_token', 'Missing Firebase ID token');

    var decoded;
    try {
        decoded = await admin.auth().verifyIdToken(token);
    } catch (err) {
        return jsonError(res, 401, 'invalid_token', 'Invalid Firebase ID token');
    }

    var body = parseBody(req.body);
    if (!body.clinicId || decoded.uid !== body.clinicId) {
        return jsonError(res, 403, 'clinic_mismatch', 'Token uid does not match clinicId');
    }

    try {
        var result;
        if (body.action === 'send_reminder') {
            await assertClinicFeature(db, body.clinicId, 'appointment_reminders');
            result = await sendReminder(body.appointmentId, body.clinicId, decoded.uid);
        } else if (body.action === 'reschedule') {
            await assertClinicFeature(db, body.clinicId, 'appointments_management');
            result = await rescheduleAppointment(body.appointmentId, body.clinicId, decoded.uid, body.newDate, body.newTime, body.reason || body.notes || '');
        } else if (body.action === 'cancel') {
            await assertClinicFeature(db, body.clinicId, 'appointments_management');
            result = await cancelAppointment(body.appointmentId, body.clinicId, decoded.uid, body.reason || body.notes || '');
        } else if (body.action === 'no_show') {
            await assertClinicFeature(db, body.clinicId, 'appointments_management');
            result = await markNoShow(body.appointmentId, body.clinicId, decoded.uid);
        } else if (body.action === 'notify_created') {
            // Dashboard just created an appointment doc directly; fire
            // a "موعد جديد" notification. Feature-gate same as the rest
            // of the management actions.
            await assertClinicFeature(db, body.clinicId, 'appointments_management');
            result = await notifyAppointmentCreated(body.appointmentId, body.clinicId);
        } else if (body.action === 'notify_deleted') {
            // Dashboard hard-deleted (or is about to delete) the
            // appointment. We can't load the doc — caller supplies the
            // identity fields inline.
            await assertClinicFeature(db, body.clinicId, 'appointments_management');
            result = await notifyAppointmentDeleted(body.clinicId, body);
        } else {
            return jsonError(res, 400, 'unknown_action', 'Unknown action');
        }

        var notification = result.notification || { sent: false };
        return res.status(200).json({
            success: true,
            action: body.action,
            appointmentId: body.appointmentId,
            notificationSent: notification.sent === true,
            notificationReason: notification.reason,
            notificationError: notification.error,
        });
    } catch (err) {
        var status = err.httpStatus || 500;
        var code = err.code || 'internal_error';
        console.error('[appointment-status-action]', code, err.message);
        if (code === 'FEATURE_NOT_ALLOWED') {
            return res.status(status).json({
                success: false,
                ok: false,
                error: code,
                code: code,
                message: err.message,
                requiredPlan: err.requiredPlan || 'pro',
            });
        }
        return jsonError(res, status, code, err.message);
    }
};
