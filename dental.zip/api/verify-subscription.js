// Clinic SaaS subscription verification (Google Play Billing).
//
// The Android app NEVER trusts its own purchase state. After a purchase it
// sends the purchase token here; this endpoint:
//   1. authenticates the caller (Firebase ID token),
//   2. verifies the purchase server-side with the Google Play Developer API,
//   3. updates the clinic subscription in Firestore (source of truth).
//
// It NEVER fakes a successful verification: if the Google Play service account
// is not configured, or the subscription is not active, it returns
// { verified: false } with a reason.
//
// TODO (post-launch): add Play RTDN (Real-Time Developer Notifications) or a
// scheduled re-verification so expiry/cancellation/hold are reconciled
// server-side without waiting for the app to re-verify on launch. This will add
// another Vercel function — first consolidate functions to stay under the Hobby
// 12-function limit . Until then,
// the app re-verifies on launch and the clients gate on expiryTime (a past
// expiryTime downgrades to Basic even if the stored status is stale).
//
// Required env for production verification:
//   GOOGLE_PLAY_SA_CLIENT_EMAIL   service-account email with Play access
//   GOOGLE_PLAY_SA_PRIVATE_KEY    service-account private key (\n escaped)
//   ANDROID_PACKAGE_NAME          defaults to com.dentalpro.dental_suite
//   (plus the existing FIREBASE_* admin credentials)
// And `googleapis` must be a dependency.

var admin = require('firebase-admin');
var crypto = require('crypto');

if (!admin.apps.length) {
  var privateKey = (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: privateKey,
    }),
  });
}

var db = admin.firestore();
var FieldValue = admin.firestore.FieldValue;

// Public plans are Basic and Pro. `subscription_elite` is kept ONLY so legacy
// Elite purchases still verify and are not broken; Elite is not sold publicly.
var PRODUCT_PLAN = {
  subscription_basic: 'basic',
  subscription_pro: 'pro',
  subscription_elite: 'elite',
};
var PACKAGE_NAME =
  process.env.ANDROID_PACKAGE_NAME || 'com.dentalpro.dental_suite';
// States that still ENTITLE the clinic to access:
//  - ACTIVE: paid & auto-renewing
//  - IN_GRACE_PERIOD: payment failed but access retained
//  - CANCELED: user turned off auto-renew but remains entitled until expiryTime
// ON_HOLD / PAUSED / EXPIRED / PENDING do NOT entitle access.
var ENTITLED_STATES = [
  'SUBSCRIPTION_STATE_ACTIVE',
  'SUBSCRIPTION_STATE_IN_GRACE_PERIOD',
  'SUBSCRIPTION_STATE_CANCELED',
];
// Map Google Play subscription states to our stored subscriptionStatus values.
var STATE_TO_STATUS = {
  SUBSCRIPTION_STATE_ACTIVE: 'active',
  SUBSCRIPTION_STATE_IN_GRACE_PERIOD: 'grace_period',
  SUBSCRIPTION_STATE_ON_HOLD: 'on_hold',
  SUBSCRIPTION_STATE_PAUSED: 'paused',
  SUBSCRIPTION_STATE_CANCELED: 'canceled',
  SUBSCRIPTION_STATE_EXPIRED: 'expired',
};

function getBearer(authHeader) {
  if (!authHeader) return '';
  var parts = String(authHeader).split(' ');
  return parts.length === 2 && /^Bearer$/i.test(parts[0]) ? parts[1] : '';
}

async function verifyIdToken(req) {
  var token = getBearer(req.headers.authorization);
  if (!token) {
    var err = new Error('Missing Firebase ID token');
    err.httpStatus = 401;
    err.code = 'MISSING_TOKEN';
    throw err;
  }
  try {
    return await admin.auth().verifyIdToken(token);
  } catch (e) {
    var bad = new Error('Invalid Firebase ID token');
    bad.httpStatus = 401;
    bad.code = 'INVALID_TOKEN';
    throw bad;
  }
}

// Verify the subscription purchase with the Google Play Developer API.
// Returns { ok, reason, state, expiry }. Never throws "valid" on failure.
async function verifyWithGooglePlay(productId, purchaseToken) {
  var saEmail = process.env.GOOGLE_PLAY_SA_CLIENT_EMAIL;
  var saKey = (process.env.GOOGLE_PLAY_SA_PRIVATE_KEY || '').replace(/\\n/g, '\n');
  if (!saEmail || !saKey) {
    return { ok: false, reason: 'play_api_not_configured' };
  }
  var google = require('googleapis').google;
  var auth = new google.auth.JWT(saEmail, null, saKey, [
    'https://www.googleapis.com/auth/androidpublisher',
  ]);
  var ap = google.androidpublisher({ version: 'v3', auth: auth });

  var resp = await ap.purchases.subscriptionsv2.get({
    packageName: PACKAGE_NAME,
    token: purchaseToken,
  });
  var data = resp.data || {};
  var state = data.subscriptionState;
  var lineItems = data.lineItems || [];
  var firstItem = lineItems[0] || {};
  var expiry = firstItem.expiryTime || null;
  var basePlanId =
    (firstItem.offerDetails && firstItem.offerDetails.basePlanId) || null;
  var matchesProduct =
    !lineItems.length ||
    lineItems.some(function (x) {
      return x.productId === productId;
    });
  var entitled = ENTITLED_STATES.indexOf(state) >= 0;
  return {
    ok: entitled && matchesProduct,
    reason: entitled ? 'verified' : state || 'inactive',
    state: state,
    status: STATE_TO_STATUS[state] || 'expired',
    basePlanId: basePlanId,
    expiry: expiry,
  };
}

module.exports = async function (req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') {
    return res.status(405).json({ verified: false, error: 'method_not_allowed' });
  }

  try {
    var decoded = await verifyIdToken(req);

    var body = req.body || {};
    if (typeof body === 'string') {
      try {
        body = JSON.parse(body);
      } catch (e) {
        body = {};
      }
    }
    var productId = (body.productId || '').toString();
    var purchaseToken = (body.purchaseToken || '').toString();
    var basePlanIdHint = (body.basePlanId || '').toString();
    var clinicId = (body.clinicId || '').toString();
    var userId = (body.userId || '').toString() || decoded.uid;

    var plan = PRODUCT_PLAN[productId];
    if (!plan || !purchaseToken) {
      return res.status(400).json({ verified: false, error: 'invalid_request' });
    }

    var v = await verifyWithGooglePlay(productId, purchaseToken);
    if (!v.ok) {
      return res.status(200).json({ verified: false, reason: v.reason });
    }

    // Store a one-way reference to the token, never the raw token.
    var tokenRef = crypto.createHash('sha256').update(purchaseToken).digest('hex');
    var update = {
      plan: plan,
      subscriptionSource: 'google_play',
      subscriptionStatus: v.status || 'active',
      productId: productId,
      basePlanId: v.basePlanId || basePlanIdHint || null,
      expiryTime: v.expiry
        ? admin.firestore.Timestamp.fromDate(new Date(v.expiry))
        : null,
      purchaseTokenRef: tokenRef,
      linkedClinicId: clinicId || null,
      linkedUserId: userId || null,
      updatedAt: FieldValue.serverTimestamp(),
    };

    if (clinicId) {
      await db.collection('clinics').doc(clinicId).set(update, { merge: true });
    }
    await db
      .collection('clinic_subscriptions')
      .doc(tokenRef)
      .set(
        Object.assign(
          { productId: productId, createdAt: FieldValue.serverTimestamp() },
          update
        ),
        { merge: true }
      );

    return res.status(200).json({
      verified: true,
      plan: plan,
      status: v.status || 'active',
      basePlanId: v.basePlanId || basePlanIdHint || null,
      expiryTime: v.expiry,
    });
  } catch (e) {
    var status = e.httpStatus || 500;
    return res.status(status).json({ verified: false, error: e.code || 'server_error' });
  }
};
