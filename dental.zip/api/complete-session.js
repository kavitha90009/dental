// Secure session completion for clinic dashboard.
// Auth: Firebase ID token in Authorization: Bearer <token>.

var admin = require('firebase-admin');

if (!admin.apps.length) {
    var privateKey = (process.env.FIREBASE_PRIVATE_KEY || '').replace(/\\n/g, '\n');
    admin.initializeApp({
        credential: admin.credential.cert({
            projectId:   process.env.FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey:  privateKey,
        }),
    });
}

var db = admin.firestore();
var FieldValue = admin.firestore.FieldValue;
var assertClinicFeature = require('./_features').assertClinicFeature;

function cleanUndefined(obj) {
    return Object.fromEntries(Object.entries(obj).filter(function(entry) {
        return entry[1] !== undefined;
    }));
}

var _utils = require('./_utils');
var getBearerToken = _utils.getBearerToken;
var parseBody      = _utils.parseBody;
var jsonError      = _utils.jsonError;
var normalizePhone = _utils.normalizePhone;
var stringData     = _utils.stringData;

function toNumber(value) {
    var n = Number(value);
    return Number.isFinite(n) ? n : 0;
}

function normalizeServices(rawServices) {
    if (!Array.isArray(rawServices)) return [];
    return rawServices.map(function(svc) {
        var price = toNumber(svc.price);
        var qty = toNumber(svc.qty || 1) || 1;
        return cleanUndefined({
            name: String(svc.name || '').trim(),
            category: svc.category || '',
            price: price,
            qty: qty,
            total: toNumber(svc.total || (price * qty)),
            notes: svc.notes || '',
            isCustom: !!svc.isCustom,
        });
    }).filter(function(svc) {
        return !!svc.name;
    });
}

function monthKeyFromDate(dateStr) {
    if (typeof dateStr === 'string' && /^\d{4}-\d{2}/.test(dateStr)) {
        return dateStr.substring(0, 7);
    }
    return new Date().toISOString().substring(0, 7);
}

function parseAppointmentDateTime(appt) {
    if (!appt || !appt.date) return null;
    var time = String(appt.time || '00:00').slice(0, 5);
    var dt = new Date(String(appt.date) + 'T' + time + ':00');
    return Number.isNaN(dt.getTime()) ? null : dt;
}

function todayDateStr(date) {
    return date.toISOString().split('T')[0];
}

// Canonical phone key — must match the digits-only form produced by both
// patient app GuestBookingIdentity and the appointment-action.js endpoint.
// Saudi local 05XX → 966XX...; Egyptian local 01XX → 20XX...
// normalizePhone is imported from ./_utils above.

async function tryGuestToken(phone) {
    if (!phone) return null;
    var key = normalizePhone(phone);
    if (!key) return null;
    var guestSnap = await db.collection('guest_fcm_tokens').doc(key).get();
    if (!guestSnap.exists) return null;
    var t = guestSnap.data().fcmToken;
    if (!t) return null;
    return { token: t, audience: 'guest', normalizedPhone: key };
}

async function resolveVisitNotificationToken(appt) {
    var patientUid = appt && appt.patientUid;
    var patientId = appt && appt.patientId;
    var apptPhone = appt && (appt.patientPhone || appt.phone || '');

    // 1) App user FCM token
    if (patientUid) {
        var appUserSnap = await db.collection('patients_app').doc(patientUid).get();
        if (appUserSnap.exists) {
            var t = appUserSnap.data().fcmToken;
            if (t) return { token: t, audience: 'app_user' };
            // App user exists but no token — fall through to phone-based lookups
            var appUserPhone = appUserSnap.data().phone || '';
            if (appUserPhone) {
                var fromAppUserPhone = await tryGuestToken(appUserPhone);
                if (fromAppUserPhone) return fromAppUserPhone;
            }
        }
    }

    // 2) Phone stored directly on the appointment (set by appointment-action.js)
    var fromApptPhone = await tryGuestToken(apptPhone);
    if (fromApptPhone) return fromApptPhone;

    // 3) Phone on the clinic's patient record
    if (patientId) {
        var manualSnap = await db.collection('patients').doc(patientId).get();
        if (manualSnap.exists) {
            var fromManualPhone = await tryGuestToken(manualSnap.data().phone || '');
            if (fromManualPhone) return fromManualPhone;
        }
    }

    return null;
}

// Best-effort enqueue for the reminders cron to retry later. Identical
// schema to the queue populated by api/appointment-action.js so the
// same flush logic handles both.
async function enqueuePendingGuestVisitSummary(appt, appointmentId, clinicId) {
    try {
        var phone = (appt && (appt.patientPhone || appt.phone)) || '';
        var key = normalizePhone(phone);
        if (!key) return;
        await db.collection('pending_guest_notifications').add({
            normalizedPhone: key,
            title: 'Your visit summary is ready',
            body: 'Your visit details have been recorded. You can review the services and cost in the app.',
            data: stringData({
                type: 'visit_summary_created',
                appointmentId: appointmentId || '',
                clinicId: clinicId || '',
                patientUid: (appt && appt.patientUid) || '',
                patientId: (appt && appt.patientId) || '',
            }),
            attempts: 0,
            reason: 'no_token_at_completion',
            createdAt: FieldValue.serverTimestamp(),
            lastTriedAt: null,
        });
    } catch (err) {
        console.warn('[pending-guest-notif] enqueue visit summary failed:', err && err.message);
    }
}

async function sendVisitSummaryNotification(appt, appointmentId, clinicId) {
    var resolved = await resolveVisitNotificationToken(appt);
    if (!resolved) {
        await enqueuePendingGuestVisitSummary(appt, appointmentId, clinicId);
        return { sent: false, reason: 'NO_FCM_TOKEN', queued: true };
    }

    await admin.messaging().send({
        token: resolved.token,
        notification: {
            title: 'Your visit summary is ready',
            body: 'Your visit details have been recorded. You can review the services and cost in the app.',
        },
        data: stringData({
            type: 'visit_summary_created',
            appointmentId: appointmentId,
            clinicId: clinicId,
            patientUid: (appt && appt.patientUid) || '',
            patientId: (appt && appt.patientId) || '',
            audience: resolved.audience,
        }),
        android: {
            priority: 'high',
            notification: {
                channelId: 'appointments',
                sound: 'default',
                priority: 'high',
            },
        },
    });
    return { sent: true, audience: resolved.audience };
}

async function completeSession(body, actorUid) {
    var appointmentId = body.appointmentId;
    var clinicId = body.clinicId;
    var services = normalizeServices(body.services);
    var totalAmount = toNumber(body.totalAmount);
    var paidAmount = toNumber(body.paidAmount);
    var remainingAmount = toNumber(body.remainingAmount);
    var paymentStatus = body.paymentStatus || '';
    var paymentMethod = body.paymentMethod || '';
    var doctorNotes = body.doctorNotes || '';
    var allowEarlyCompletion = body.allowEarlyCompletion === true;
    var completionNow = new Date();

    if (!appointmentId || !clinicId) {
        var missing = new Error('appointmentId and clinicId are required');
        missing.httpStatus = 400;
        missing.code = 'MISSING_FIELDS';
        throw missing;
    }
    if (!services.length) {
        var noServices = new Error('services are required');
        noServices.httpStatus = 400;
        noServices.code = 'NO_SERVICES';
        throw noServices;
    }

    await assertClinicFeature(db, clinicId, 'session_revenue_recording');

    return db.runTransaction(async function(tx) {
        var apptRef = db.collection('appointments').doc(appointmentId);
        var apptSnap = await tx.get(apptRef);
        if (!apptSnap.exists) {
            var notFound = new Error('appointment not found');
            notFound.httpStatus = 404;
            notFound.code = 'APPOINTMENT_NOT_FOUND';
            throw notFound;
        }

        var appt = apptSnap.data() || {};
        if (appt.clinicId !== clinicId) {
            var wrongClinic = new Error('wrong clinic');
            wrongClinic.httpStatus = 403;
            wrongClinic.code = 'WRONG_CLINIC';
            throw wrongClinic;
        }
        if (appt.status === 'completed' || appt.completedAt) {
            var already = new Error('APPOINTMENT_ALREADY_COMPLETED');
            already.httpStatus = 409;
            already.code = 'APPOINTMENT_ALREADY_COMPLETED';
            throw already;
        }
        // Cancelled / rejected / no-show / soft-deleted appointments must
        // never become a billable session. The dashboard's checkout
        // workflow is supposed to gate on this client-side too, but we
        // enforce server-side so a stale tab or a future automation can't
        // resurrect a cancelled appointment into the revenue ledger.
        if (appt.status === 'cancelled' || appt.status === 'rejected' ||
            appt.status === 'no_show'   || appt.deleted === true) {
            var blocked = new Error('APPOINTMENT_CANCELLED');
            blocked.httpStatus = 409;
            blocked.code = 'APPOINTMENT_CANCELLED';
            throw blocked;
        }

        var scheduledAt = parseAppointmentDateTime(appt);
        var earlyMinutes = scheduledAt ? Math.ceil((scheduledAt.getTime() - completionNow.getTime()) / 60000) : 0;
        if (earlyMinutes > 1440) {
            var tooFar = new Error('APPOINTMENT_TOO_FAR_IN_FUTURE');
            tooFar.httpStatus = 400;
            tooFar.code = 'APPOINTMENT_TOO_FAR_IN_FUTURE';
            throw tooFar;
        }
        if (earlyMinutes > 0 && !allowEarlyCompletion) {
            var inFuture = new Error('APPOINTMENT_IN_FUTURE');
            inFuture.httpStatus = 409;
            inFuture.code = 'APPOINTMENT_IN_FUTURE';
            throw inFuture;
        }

        var completedEarly = earlyMinutes > 0;
        var dateStr = todayDateStr(completionNow);
        // Analytics are bucketed by the appointment's scheduled month, not
        // the calendar day the early checkout happened on. Keeps monthly
        // revenue aligned with the day the work was scheduled for and
        // prevents revenue from leaking across month boundaries when a
        // clinic checks an appointment out a day or two early.
        var analyticsDateBasis = (completedEarly && appt.date) ? appt.date : dateStr;
        var month = monthKeyFromDate(analyticsDateBasis);
        var analyticsRef = db.collection('analytics').doc(clinicId).collection('monthly').doc(month);
        var analyticsSnap = await tx.get(analyticsRef);
        var existing = analyticsSnap.exists ? analyticsSnap.data() || {} : {};
        var treatmentCounts = Object.assign({}, existing.treatmentCounts || {});
        var treatmentRevenue = Object.assign({}, existing.treatmentRevenue || {});

        services.forEach(function(svc) {
            var cat = svc.category || svc.name;
            treatmentCounts[cat] = (treatmentCounts[cat] || 0) + (svc.qty || 1);
            treatmentRevenue[cat] = (treatmentRevenue[cat] || 0) + (svc.total || svc.price || 0);
        });

        tx.update(apptRef, cleanUndefined({
            status: 'completed',
            completedAt: FieldValue.serverTimestamp(),
            completedBy: actorUid,
            completedEarly: completedEarly,
            completedEarlyByMinutes: completedEarly ? earlyMinutes : 0,
            originalAppointmentDate: completedEarly ? appt.date : undefined,
            originalAppointmentTime: completedEarly ? appt.time : undefined,
            totalAmount: totalAmount,
            paidAmount: paidAmount,
            remainingAmount: remainingAmount,
            paymentStatus: paymentStatus,
            paymentMethod: paymentMethod,
            doctorNotes: doctorNotes,
        }));

        services.forEach(function(svc) {
            var svcRef = apptRef.collection('session_services').doc();
            tx.set(svcRef, cleanUndefined({
                name: svc.name,
                category: svc.category || '',
                price: svc.price,
                qty: svc.qty || 1,
                total: svc.total,
                notes: svc.notes || '',
                isCustom: !!svc.isCustom,
                clinicId: clinicId,
                createdAt: FieldValue.serverTimestamp(),
            }));
        });

        var patientUid = appt.patientUid;
        if (patientUid) {
            var visitRef = db.collection('patients_app').doc(patientUid).collection('visits').doc();
            tx.set(visitRef, cleanUndefined({
                appointmentId: appointmentId,
                clinicId: clinicId,
                date: dateStr,
                time: appt.time,
                services: services.map(function(svc) {
                    return cleanUndefined({
                        name: svc.name,
                        category: svc.category || '',
                        price: svc.price,
                        qty: svc.qty || 1,
                        total: svc.total,
                        notes: svc.notes || '',
                    });
                }),
                treatments: services.map(function(svc) {
                    return cleanUndefined({
                        name: svc.name,
                        category: svc.category || '',
                        price: svc.price,
                        notes: svc.notes || '',
                    });
                }),
                totalAmount: totalAmount,
                paidAmount: paidAmount,
                remainingAmount: remainingAmount,
                paymentStatus: paymentStatus,
                paymentMethod: paymentMethod,
                doctorNotes: doctorNotes,
                createdAt: FieldValue.serverTimestamp(),
            }));
        }

        // Deprecated aggregate. Official revenue is calculated from completed appointments paidAmount to avoid double counting.
        tx.set(analyticsRef, {
            totalRevenue: (existing.totalRevenue || 0) + paidAmount,
            totalBilled: (existing.totalBilled || 0) + totalAmount,
            unpaidAmount: (existing.unpaidAmount || 0) + remainingAmount,
            completedAppointments: (existing.completedAppointments || 0) + 1,
            treatmentCounts: treatmentCounts,
            treatmentRevenue: treatmentRevenue,
        }, { merge: true });

        return {
            appointmentId: appointmentId,
            clinicId: clinicId,
            patientUid: patientUid || null,
            patientId: appt.patientId || null,
            patientName: appt.patientName || null,
            // Pass the full pre-completion appointment data to the
            // notification resolver so it can use patientPhone directly.
            appt: appt,
        };
    });
}

module.exports = async function handler(req, res) {
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method Not Allowed' });

    var token = getBearerToken(req.headers.authorization);
    if (!token) return jsonError(res, 401, 'MISSING_TOKEN', 'Missing Firebase ID token');

    var decoded;
    try {
        decoded = await admin.auth().verifyIdToken(token);
    } catch (err) {
        return jsonError(res, 401, 'INVALID_TOKEN', 'Invalid Firebase ID token');
    }

    var body = parseBody(req.body);
    if (!body.clinicId || decoded.uid !== body.clinicId) {
        return jsonError(res, 403, 'CLINIC_MISMATCH', 'Token uid does not match clinicId');
    }

    try {
        var result = await completeSession(body, decoded.uid);
        var notification = { sent: false, reason: 'NO_PATIENT_IDENTITY' };
        if (result.appt) {
            try {
                notification = await sendVisitSummaryNotification(
                    result.appt,
                    result.appointmentId,
                    result.clinicId
                );
            } catch (notifyErr) {
                notification = { sent: false, error: notifyErr.message };
            }
        }
        if (notification && notification.sent === false) {
            console.warn('[notify] visit-summary notification failed', {
                appointmentId: result.appointmentId,
                clinicId: result.clinicId,
                reason: notification.reason || 'unknown',
                queued: notification.queued === true,
                error: notification.error || null,
            });
        }

        return res.status(200).json({
            success: true,
            appointmentId: result.appointmentId,
            notificationSent: notification.sent === true,
            notificationReason: notification.reason,
            notificationError: notification.error,
        });
    } catch (err) {
        var status = err.httpStatus || 500;
        var code = err.code || 'INTERNAL_ERROR';
        console.error('[complete-session]', code, err.message);
        if (code === 'FEATURE_NOT_ALLOWED') {
            return res.status(status).json({
                success: false,
                ok: false,
                error: code,
                code: code,
                message: err.message,
                requiredPlan: err.requiredPlan || 'pro',
            });
        }
        return jsonError(res, status, code, err.message);
    }
};
